#include <iostream>

using namespace std;

class Traveler
{
public:
	Traveler(int n): n(n), distance(0){} // default constructor with an initializer list 
	~Traveler (){}

	void travel(int to, int back)
	{
		distance += to + back;

	}
	void algorithm1()
	{
		distance = 0;
		for (int i = 0; i < n; i++)
		{
			travel(1, 0);// simulating going to the destination
		}
		travel(0, n); // simulating going back to shop
	}

	void algorithm2()
	{
		distance = 0;
		for (int i = 1; i <= n; i++)
		{
			travel(i, i);// simulating going to the destination
		}

	}

	int distanceTraveled() const // this function cant change the object
	{
		return distance;
	}


private:
	int distance:
	int n;

};


int main()
{
	Traveler car(50);// automatic which is in the stack
	Traveler* bike = new Traveler(50); // dynamic which is in the heap 

	car.algorithm1();
	cout << "A1: " << car.distanceTraveled() << endl;

	bike->algorithm2();
	cout << "A2: " << bike->distanceTraveled() << endl;

	delete bike; // removes bike data from heap so it will not leak memory


	system("pause");
	return 0;
}