#include <iostream>

using namespace std;

void travel(int to, int back, int& distance)
{
	distance += to + back;

}
void algorithm1(int n, int& distance)
{
	distance = 0;
	for (int i = 0; i < n; i++)
	{
		travel(1, 0, distance);// simulating going to the destination
	}
	travel(0, n, distance); // simulating going back to shop
}

void algorithm2(int n, int& distance)
{
	distance = 0;
	for (int i = 1; i <= n; i++)
	{
		travel(i, i, distance);// simulating going to the destination
	}

}
/*int main()
{
	int distance = 0;
	int n = 50;

	algorithm1(n, distance);
	cout << "A1: " << distance << endl;

	algorithm2(n, distance);
	cout << "A2: " << distance << endl;


	system("pause");
	return 0;
}*/