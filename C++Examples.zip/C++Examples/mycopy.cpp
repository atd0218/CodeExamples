#include<iostream>
#include<fstream>
using namespace std;

int main()
{
	char input[100];

	cout << "Please enter the source file name: ";
	cin.getline(input, 100);

	ifstream in(input, ios::binary);

	if (!in.good())
	{
		cerr << "Unable to open  " << input << endl;
		system("pause");
		exit(1);
	}

	char output[100];
	cout << "Please enter the destination file name: ";
	cin.getline(output, 100);

	ofstream out(output, ios::binary);

	if (!out.good())
	{
		cerr << "Unable to open " << output << endl;
		system("pause");
		exit(1);
	}

	//character copy

	/*int c;

	while ((c = in.get()) != EOF)
	{
		out.put(c);
	}
*/
	// block copy

	//char buffer[512];
	//int  count;

	//in.read(buffer, 512); // buffer is being passed as an address 

	//while ((count = in.gcount()) > 0)
	//{
	//	out.write(buffer, count);
	//	in.read(buffer, 512);
	//}

	// buffer copy

	out << in.rdbuf(); // gives us address of read buffer then the extraction operator will take everything
	// and copy it over to the next file




	system("pause");
	return 0;
}