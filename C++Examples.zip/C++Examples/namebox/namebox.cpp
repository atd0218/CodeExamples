#include<iostream>
#include<string> // for string version
#include<cstring>
using namespace std;

//int main()	versions 1 or 2 
int main(int argc, char* argv[]) // version 3 
{
	// string class version
	/*string name;
	cout << "Please enter your name: ";
	getline(cin, name);

	//desinging top of box
	cout << '+';
	for (unsigned i = 0; i < name.length(); i++)
	{
		cout << '-';
	}
	cout << '+' << endl;

	//desinging middle of box

	cout << '|' << name << '|' << endl;

	//desinging bottom of box
	cout << '+';
	for (unsigned i = 0; i < name.length(); i++)
	{
		cout << '-';
	}
	cout << '+' << endl; */

	// c-string version

	//char name[100];
	//cout << "Please enter your name: ";
	//cin.getline(name, 100);

	////desinging top of box
	//cout << '+';
	//for (unsigned i = 0; i < strlen(name); i++)
	//{
	//	cout << '-';
	//}
	//cout << '+' << endl;

	////desinging middle of box

	//cout << '|' << name << '|' << endl;

	////desinging bottom of box
	//cout << '+';
	//for (unsigned i = 0; i < strlen(name); i++)
	//{
	//	cout << '-';
	//}
	//cout << '+' << endl;

	//command line version

	int count = 0;

	for (int i = 1; i < argc; i++)
	{
		count += strlen(argv[i]);
	}
	count += argc - 2;

	//char name[100];
	//cout << "Please enter your name: ";
	//cin.getline(name, 100);

	//desinging top of box
	cout << '+';
	for (int i = 0; i < count; i++)
	{
		cout << '-';
	}
	
	cout << '+' << endl;

	//desinging middle of box

	cout << '|';
	for (int i = 1; i < argc - 1; i++)
	{
		cout << argv[i] << ' ';
	}
	cout << argv[argc - 1] << '|' << endl;

	//desinging bottom of box
	cout << '+';
	for (int i = 0; i < count; i++)
	{
		cout << '-';
	}
	cout << '+' << endl;



	system("pause");
	return 0;
}