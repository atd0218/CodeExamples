#include<iostream>
#include<string>
using namespace std;

string reverse(string s); // function decleration
string myto_string(int n); // function decleration

int main()
{
	

	for (int number = 1; ; number++) // how we generate candidate numbers
	{
		int square = number * number;
		//string s = to_string(square);
		string s = myto_string(square);

		if (s.length() < 6)		// case 6 or more digits
		{
			continue;  // if statement false we will skip that portion
		}

		if (s.find('0') == 0 || s.rfind('0') == s.length() - 1) // case does not begin or end with 0
		{
			continue;
		}

		if (s == reverse(s))
		{
			cout << number << " " << square << endl;
			break;
		}

		/*unsigned i; // case is a palindrome
		for (i = 0; i < s.length() / 2; i++)
		{
			if (s[i] != s[s.length() - 1 - i])
			{
				break;
			}
		}

		if (i == s.length() / 2) // did our fingers meet in middle 
		{
			cout << number << " " << square << endl;
			break;
		}*/
		
		
	}

	


	system("pause");
	return 0;
}

string reverse(string s)
{
	string r;

	for (unsigned i = 0; i < s.length(); i++)
	{
		r += s[s.length() - 1 - i];
	}

	return r;
	
}

string myto_string(int n)
{
	string s;
	string sign = "";

	if (n < 0)
	{
		sign = "-";
		n *= -1;
	}

	do
	{
		s = (char)(n % 10 + '0') + s; // converts last digit to char value
		n /= 10;
	} while (n);

	return sign + s;
}