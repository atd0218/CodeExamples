#include <iostream>
#include <iomanip>
using namespace std;

void fill_table(int table[][12]);
void print_table(int table[][12]);


int main()
{
	int	table[12][12];		// rows x cols		// (a)

	fill_table(table);					// (b)
	print_table(table);					// (c)

	return 0;
}


void fill_table(int table[][12])				// (d)
{
	for (int row = 1; row <= 12; row++)
		for (int col = 1; col <= 12; col++)
			table[row - 1][col - 1] = row * col;
}

void print_table(int table[][12])				// (e)
{
	for (int row = 0; row < 12; row++)
	{
		for (int col = 0; col < 12; col++)
			cout << setw(4) << table[row][col];
		cout << endl;
	}
}