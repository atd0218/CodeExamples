#include <iostream>
using namespace std;

int N(int k, int* fo);
double chi2(int k, int fo[]);

int main()
{
	int fo[100]; // defining an array with the braces
	int f;
	//int N = 0; // initialize to become clear when programming // 1st attempt
	int k = 0; // initialize for clearness 

	cout << "Enter the observed frequencies for each category, -1 to end: ";

	cin >> f;
	while (f != -1)
	{
		fo[k++] = f; // everytime a category entered k will incriment
		cin >> f;


	}
	
	cout << "Chi-square = " << chi2(k,fo) << endl;

	system("pause");
	return 0;
}

int N(int k, int* fo)
{
	int N = 0;

	for (int i = 0; i < k; i++)
	{
		N += fo[i];
	}

	return N;

}

double chi2(int k, int fo[])
{
	//double fe = (double)N(k, fo) / k; // (double) casts N as a double to avoid truncation
	double fe = double(N(k, fo)) / k;

	double sum = 0;
	for (int i = 0; i < k; i++)
	{
		sum += (fo[i] - fe) * (fo[i] - fe);

	}
	double chi2 = sum / fe;

	return chi2;
}