#include <iostream>
#include <iomanip>
#include "time.h"
using namespace std;

//Time::Time(int h, int m, int s)
//{
//	hours = h;		// general constructor
//	minutes = m;
//	seconds = s;
//}

Time::Time(int s)
{


	hours = s / 3600;
	s %= 3600;
	minutes = s / 60;
	seconds = s % 60;



}
// class version
//void Time::print()
//{
//	cout << hours << ":" << minutes << ":" << seconds << endl;
//}

//overloaded operator version
ostream& operator<<(ostream& out, Time& me)
{
	out << me.hours << ":" << me.minutes << ":" << me.seconds << endl;
	return out;
}

Time operator+(Time t1, Time t2)
{
	int i1 = t1.hours * 3600 + t1.minutes * 60 + t1.seconds;
	int i2 = t2.hours * 3600 + t2.minutes * 60 + t2.seconds;

	return Time(i1 + i2);
}

//Class version
//Time Time::add(Time t2)
//{
//	int i1 = this->hours * 3600 + this->minutes * 60 + this->seconds;
//	int i2 = t2.hours * 3600 + t2.minutes * 60 + t2.seconds;	// still have to specify that these hours belong to t2
//
//	return Time(i1 + i2);
//}


istream& operator>>(istream& in, Time& me)
{
	cout << "Please enter the hours: ";
	in >> me.hours;

	cout << "Please enter the minutes: ";
	in >> me.minutes;

	cout << "Please enter the seconds: ";
	in >> me.seconds;

	return in;
}

// class version
//void Time::read()
//{
//	cout << "Please enter the hours: ";
//	cin >> hours;
//
//	cout << "Please enter the minutes: ";
//	cin >> minutes;
//
//	cout << "Please enter the seconds: ";
//	cin >> seconds;
//}
