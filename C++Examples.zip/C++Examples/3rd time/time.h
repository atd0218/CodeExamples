#pragma once
#include <iostream>
using namespace std;

class Time
{
private:
	int hours;
	int minutes;
	int seconds;

public:
	Time() : hours(0), minutes(0), seconds(0) {}		// initializer list
														/*{
														hours = 0;
														minutes = 0;		// default constructor
														seconds = 0;
														}*/

	Time(int h, int m, int s) : hours(h), minutes(m), seconds(s) {}		// initializer list

	Time(int s);

	//operator version

	friend Time operator+(Time t1, Time t2);

	friend ostream& operator<<(ostream& out, Time& me);

	friend istream& operator>>(istream& in, Time& me);                  //pass by pointer


};


