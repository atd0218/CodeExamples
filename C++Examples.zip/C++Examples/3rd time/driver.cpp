#include <iostream>
#include "time.h"
using namespace std;

int main()
{

	// operator version

	Time t1(3666);
	cout << t1 << endl;

	//Time t2
	Time t2;
	cin >> t2;
	cout << t2 << endl;

	Time t3 = t1 + t2;
	cout << t3 << endl;

	t3 = t1 + 5;
	cout << t3 << endl;

	t3 = 5 + t2;
	cout << t3 << endl;


	system("pause");
	return 0;



}