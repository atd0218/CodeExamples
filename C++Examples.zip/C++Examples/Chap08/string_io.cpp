#include <string>
#include <iostream>
using namespace std;

int main()
{
	// c-string version

	/*char input[100]; // defining c-string
	//cin >> input;	// >> function will not read any characters pass spaces

	cin.getline(input, 100); // getline requires what you are reading from and the length of the string array (input, 100)
	(input, 100) input is a pass by pointer because info is going in and coming back out
	cout << input << endl; */

	// string class version

	string input;
	//cin >> input;
	getline(cin, input); // first parameter is where info is coming from second parameter is where data is stored
	//(cin, input) input is pass by reference 
	cout << input << endl;

	system("pause");
	return 0;
}