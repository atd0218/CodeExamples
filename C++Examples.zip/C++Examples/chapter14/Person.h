#ifndef _PERSON_H_			// called include guard
#define _PERSON_H_			// named after file which is usually named after the class

#include "Address.h"
#include "Date.h"
#include <iostream>
#include <string>
using namespace std;

class Person
{
private:
	string name;
	Address addr;	// Composition Accessor
	Date* date;		// Aggregation Accessor
public:
	Person(string n, string s, string c) : name(n), addr(s, c), date(nullptr) {}	
	//															^AGGREGATION weak bonding thats why we set it to nullptr
	//												^COMPOSITION strong bonding

	~Person()	//  Destructor which never takes any objects starts with ~ always
	{
		// made to help support the aggregation in this program
		if (date != nullptr)
		{
			delete date;
		}
	}

	void setDate(int y, int m, int d) // setter functions allow other objects to access private variables of the whole class
	{
		// made to support aggregation in this program
		if (date != nullptr)			// Prevent a memory leak
		{
			delete date;
		}

		date = new Date(y, m, d);
	}

	string getName()
	{
		return name;
	}
	// virtual void display for polymorphism version
	virtual void display()
	{
		cout << name << endl; 
		addr.display();			// COMPOSITION
		if (date != nullptr)	// AGGREGATION
		{
			date->display();
		}

	}

	friend ostream& operator<<(ostream& out, Person& me) // second parameter must be same as class
	{
		out << me.name << endl;
		out << me.addr << endl;
		if (me.date != nullptr)
		{
			out << *me.date;	//dereference the pointer so we can use it as a normal me.date
		}
		out << endl;
		return out;
	}

};

#endif