#include<iostream>
#include<algorithm>
#include <string>
#include "Person.h"
#include "Actor.h"
#include "Star.h"
#include "CList.h"

using namespace std;



int main()
{
	CList<Person> people;

	Star* s2 = new Star("John Wayne", "Cranston Snort", 50000000, "115 Elm", "Ogden");
	s2->setDate(1960, 12, 25);

	people.insert(s2);

	Actor* a = new Actor("Dilbert", "Wally", "2401 evalson", "Ogden");
	a->setDate(1956, 5, 22);
	people.insert(a);

	Person* p = new Person("Alice", "1234 johnson way", "Ogden");
	p->setDate(2003, 2, 18);
	people.insert(p);

	people.list();


	system("pause");
	return 0;
}