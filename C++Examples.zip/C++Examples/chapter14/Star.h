#pragma once

#include <iostream>
#include <string>
#include "Actor.h"
using namespace std;


class Star : public Actor
{
private:
	double balance;

public:
	Star(string n, string a, double b, string s, string c) : Actor(n, a, s, c), balance(b) {}

	void display()
	{

		Actor::display();
		cout << balance << endl;
	}

	friend ostream& operator<<(ostream& out, Star& me)
	{
		out << (Actor &)me << " " << me.balance << endl;

		return out;
	}

};