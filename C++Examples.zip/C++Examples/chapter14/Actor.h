#pragma once

#include <iostream>
#include <string>
#include "Person.h"
using namespace std;

class Actor : public Person			// introduce the inheritance that actor class is a child of person class
{
private:
	string agent;

public:
	Actor(string n, string a, string s, string c) : Person(n, s, c), agent(a) {}			// first parameter calls the constructor in the parent class 

	void display()
	{
		Person::display();		// how to call display for the parent class

		cout << agent << endl;
	}

	friend ostream& operator<<(ostream& out, Actor& me)
	{
		out << (Person &)me << " " << me.agent << endl;


		return out;
	}
};