//#define SIZE 100	// choose oone of the 3
//enum { SIZE = 100; }
const int SIZE = 100;

struct stack
{
	char	st[SIZE];
	int	sp;
};

stack make_stack();		// choose one of
void init_stack(stack* s);	// make_stack or init_stack
void push(stack* s, char data);
char pop(stack* s);
int size(stack* s);
char peek(stack* s);

