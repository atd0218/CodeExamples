#include<iostream>
#include "stack.h"
using namespace std;

stack make_stack()
{
	stack	temp;
	temp.sp = 0;
	return temp;
}

void init_stack(stack* s)
{
	s->sp = 0;
}

void push(stack* s, char data)
{
	if (s->sp < SIZE)
		s->st[s->sp++] = data;
	else
		cerr << "ERROR: stack is full" << endl;
}

char pop(stack* s)
{
	if (s->sp > 0)
		return s->st[--(s->sp)];
	else
	{
		cerr << "ERROR: stack is empty" << endl;
		return '\0';	// no good value to return
	}
}

int size(stack* s)
{
	return s->sp;
}

char peek(stack* s)
{
	return s->st[s->sp - 1];
}

