#include<iostream>
#include<cstring>
#include"stack.h"
using namespace std;

void itoa(int n, char* s);
void reverse(char* s);

int main()
{

	for (int number = 1; ; number++) // created infinite for loop need somewhere to stop it 
	{
		int square = number * number;
		char s[100];
		//_itoa(square, s, 2);		// common but not ANSI
		//_itoa_s(square, s, 100, 2);	// Microsoft safe version
		itoa(square, s);

		if (strlen(s) < 6)
		{
			continue;
		}

		if (s[0] == '0' || s[strlen(s) - 1] == '0')
		{
			continue;
		}

		/*unsigned i;
		for (i = 0; i < strlen(s) / 2; i++)
		{
			if (s[i] != s[strlen(s) - 1 - i])
			{
				break;
			}

		}

		if (i == strlen(s) / 2)
		{
			cout << number << " " << square << endl;
			break;
		}*/

		char r[100];

		strcpy_s(r, s);
		reverse(r);

		if (strcmp(s, r) == 0)
		{
			cout << number << " " << square << endl;
			break;
		}



	}

	system("pause");
	return 0;
}

void itoa(int n, char* s)
{
	bool sign = n < 0;
	stack st;

	init_stack(&st);	// sets stack pointer to 0

	if (sign)
	{
		n = -n;
	}

	do
	{
		push(&st, (char)(n % 10 + '0'));
		n /= 10;
	} while (n);

	if (sign)
	{
		push(&st, '-');

	}

	int index = 0;
	while (size(&st) > 0)
	{
		s[index++] = pop(&st);
	}
	s[index] = '\0';
}

void reverse(char* s)
{
	for (unsigned i = 0; i < strlen(s) / 2; i++)
	{
		char temp = s[i];
		s[i] = s[strlen(s) - 1 - i];
		s[strlen(s) - 1 - i] = temp;
	}
}