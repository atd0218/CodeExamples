#include <iostream>
#include <cmath>
using namespace std;

double rms(double x[], int n);

int main()
{
	const int MAX = 100;

	int n = 0;
	//double x[MAX]; automatic array exp

	double* x = new double[MAX]; // Dynamic array exp 

	do
	{
		cout << "Enter an x value (EOF to end): ";
		cin >> x[n++];

	} while (!cin.eof()); // eof means end of file as long as we not at end of input we will keep looping
	n--;		// n incremented when eof is entered 

	if (n > 0)
	{
		cout << "RMS = " << rms(x, n) << endl;
	}


	system("pause");
	return 0;
}

double rms(double x[], int n)
{
	double sum = 0;

	for (int i = 0; i < n; i++)
	{
		sum += pow(x[i], 2); // pow(base, exponent)

		

	}
	return sqrt(sum / n);
}