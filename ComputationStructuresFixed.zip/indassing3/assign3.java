//Ashton Daniels
//CS 2130 - 11:30am
//Individual Assignment 3
//Dr Huson
//Due 02/28/2019
//Filename: assign3.java


//-------------------------------------------------------------------
//This program takes in input from a file and then creates a truth table
//and tells you the sum of products expansion
//-------------------------------------------------------------------

import java.io.File;
import java.util.Scanner;
import java.util.ArrayList;
import java.io.*;

public class assign3
{
   public static void main (String[]args)
   {
      //variables
      int x = 0;//xyzf are variables for truth table
      int y = 0;
      int z = 0;
      int f = 0;
      int[][] intarray = new int[8][4];//array initialization
      boolean alreadyadd = false;// to tell where a + should be for sum of products
      
      //instance of scanner to read input
      Scanner in = new Scanner(System.in);
      
      //get input from user through keyboard or input redirection
      System.out.println("X,Y,Z,F(x,y,z)");
      for(int i = 0; i < 8; i++)
      {
         for(int j = 0; j < 4; j++)
         {
            intarray[i][j] = in.nextInt();
            

         }//end second for
         
      }//end first for
      
      
      //format and printing of the truth table
      System.out.println("Truth Table:");
      System.out.println("X" + " " + "Y" + " " + "Z" + " " + " " + "F(x,y,z)");
      for(int i = 0; i < 8; i++)
      {
         System.out.print(intarray[i][0] + " " + intarray[i][1] + " " + intarray[i][2] + 
         " " + " " + " " + " " +intarray[i][3] + "\n");
      }
      
      
      //for loops of conditional statements to correctly print sum of products expansion
      for(int i = 0; i < 8; i++)
      {
         if(intarray[i][3]==1)
         {
         
            if(alreadyadd)
            {
               System.out.print("+" + " ");
            }
            if(intarray[i][0]==1)
            {
               System.out.print("X");
            }
            else
            {
               System.out.print("X'");
            }
            if(intarray[i][1]==1)
            {
               System.out.print("Y");
            }
            else
            {
               System.out.print("Y'");
            }
            if(intarray[i][2]==1)
            {
               System.out.print("Z");
            }
            else
            {
               System.out.print("Z'");
            }
            alreadyadd = true; 
            
         }//end if
      }//end for
      
      
      
  }//end main
}//end class
