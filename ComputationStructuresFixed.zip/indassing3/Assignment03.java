//Brittney Daniels
//CS 2130 - 11:30am
//Individual Assignment 3
//Dr Huson
//Due 02/28/2019
//Filename: Assignment03ComputationalStructures.java


//-------------------------------------------------------------------
//This Program Will Import Truth Tables and then Generate 
//the Truth Table Value as well as Determine the 
//Sum of Products Expansion for the Variables X,Y,Z + X,Y,Z.
//-------------------------------------------------------------------

import java.io.File;
import java.util.Scanner;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.io.*;


public class Assignment03
{
   public static void main (String[]args)
   {
      //Scanner 
      Scanner in = new Scanner (System.in);
      File userFile;
      Scanner fileIn;
      
      
      //Initializing Variables
      String fileName = "";
      String line ="";
     
     
      
   
      //Getting File Information From User 
      System.out.println("Please Enter the Name of File You Would Like To Use.");
      fileName = in.nextLine();
      
      //Instructing Program to Examine Truth Table and Decide the Sum-of Product
      //Expansion for Each Truth Table 
      
      
      
      System.out.println("Truth Table Results:");
      System.out.println("==================");
      System.out.println("X Y Z F(x,y,z)");
      System.out.println("==================");
try
 {   
    //Building File and Attaching Scanner 
    userFile = new File (fileName);
    fileIn = new Scanner (userFile);
    

   //While There is a Line to Be Read
   while (fileIn.hasNextLine())
   {
      line = fileIn.nextLine();
      
      System.out.println(line);
      
      //For Loop with Conditional Statements 
      //-----------------------------------------
   //System.out.println("Sum of Products Expansions");
     if(line.end == 1)
     {
     
     }
        
        
   }
   
   }   
      catch (Exception FileNotFoundException)
         {
               System.out.println ("Sorry, the File Entered Was Not Found. Please Re-Enter");
          
         }
      
      

   }

}