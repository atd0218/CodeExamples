//Ashton Daniels
//CS 2130 - 11:30am
//Individual Assignment 6
//Dr Huson.
//Due 04/16/2019
//Filename: assign6.java


/*
this program allows input for 2 differnt matrices, then it will list
them as well as list the meet, join, product, complement, 
transpose, reflexive relation, symmetric relation, 
transitive relation. 
*/

//import files
import java.util.*;
import java.io.*;

public class assign6
{  
   int state = 0;
   String[] inputstring = new String[256];
   Scanner in = new Scanner(System.in);

   public static int nextState(int state, char symbol)
   {
     
      
     int[][] sttab ={
                    {0,1,0},
                    {1,2,1},
                    {2,2,3},
                    {2,2,3}
                    
                    };
      sttab[4][3] = sttab[state][symbol -'a'];
                    
      if(symbol < 'a' || symbol > 'c')
      {
         System.out.println("-1");
         
      
      } 
     
   }
   
   public boolean accept(int state)
   {
   
   }
   
   public boolean validString(String word)
   {
      int length = inputstring.length;
      for(int i = 0; i < length; i++)
      {
         word = nextState(state,c[i]);
      }
      
      return word;
   }
   
   public static void main (String[]args)
   {
      
   }
}