//Ashton Daniels
//CS 2130 - 11:30am
//Individual Assignment 4
//Dr Huson
//Due 02/28/2019
//Filename: assign4.java


//-------------------------------------------------------------------
//This program takes two numbers and first will tell you if they are prime or not
//Then they will tell you what the G.C.D is for the two numbers
//Then we use permutation combinantion and binomial distribuition to 
//calculate probabilty for certain events
//-------------------------------------------------------------------

import java.util.*;
import java.lang.*;

public class assign4
{
   //function to determine greatest common divisor
   public static int gcd(int a, int b)
   {
      if(a == 0)
      {
         return b;
      }
      
      return gcd(b%a, a);
   }
   
   //function establishing factorial calculations modified 
   public static long factorial(long n)
   {
      
      if(n==1)
      {
         return 1;
      }
      else
         return(n-1)*n;
   }
   //permutation function modified with for loop
   public static long permute(long n, long r)
   {
      long i;
      long result = 1;
      
      for(i = (n-r + 1); i <=n; i++)
      {
         result *= i; 
      }
      
      return result;
   }
   //combination function modified with for loop
   public static long combinate(long n, long r)
   {
      long result = permute(n,r);
      long i;
      for(i=1; i <= r; i++)
      {
         result /= i;
      }
      
      return result;
      
   }
   //binomial distribution function
   public static double binom(long k, long n, double p)
   {
      double q = 1 - p;
      double powr =  Math.pow(p, k);
      double pow =  Math.pow(q, n-k);
      double binom = ((double) combinate((long)n,(long)k)) 
      * Math.pow(p,k)  * Math.pow(q, n-k);
      
      return binom;
   }
   
   //main method
   public static void main (String[]args)
   {
        //variables
        int num = 0;
        int num2 = 0;
        int i = 2;
        int g = 0;
        double d = 0.075;
        long l = (long) d;
        boolean flip = true;
        boolean flip2 = true;
        Scanner in = new Scanner(System.in);
        
        //set up input to enter in 2 numbers
        System.out.println("Please enter the first number less than 10000");
        num = in.nextInt();
        //check if num is less than 10000
        if(num > 10000)
        {
            System.out.println("Sorry number must be below 10000");
            num = in.nextInt();
        }
        
        System.out.println("Please enter the second number less than 10000");
        num2 = in.nextInt();
        //check if num2 is less than 10000
        if(num2 > 10000)
        {
            System.out.println("Sorry number must be below 10000");
            num2 = in.nextInt();
        }
        
        //while loop to continue why i is less than num /2 
        while(i <= num/2)
        {
            // condition for nonprime number
            if(num % i == 0)
            {
                flip = false;
                break;
            }
            
            ++i;
        }//end while
        
        while(i <= num2/2)
        {
            // condition for nonprime number
            if(num2 % i == 0)
            {
                flip2 = false;
                break;
            }

            ++i;
        }//end while
        
       
        // conditional statements on whether it is prime or not
        if(flip)
        {
            System.out.println(num + " is a prime number.");      
        }
        else
        {
            System.out.println(num + " is a composite number.");
        }
        
        if(flip2)
        {
            System.out.println(num2 + " is a prime number.");  
        }
        else
        {
            System.out.println(num2 + " is a composite number.");
        }
        
        
        //output section for permute combinate and binomial distribution
        g = gcd(num,num2);
        System.out.println("G.C.D of " + num + " and " + num2 + " is " + g);
        
        System.out.println("number of ways 4 are selected" +
                           " for differnt prizes values is " + permute(20,4)); 
        System.out.println("number of ways 4 are selected" +
                           " for the same prize values is " + combinate(20,4));
        double pr1 = combinate(47,10);
        double pr2 = combinate(47,9);
        double pr3 = combinate(3,1);
        double pr4 = combinate(50,10);
        double pr5 = pr2 * pr3;
        
        System.out.println("out of 10 bombs chosen the probability" + 
        " that at most 1 is defective is " + (pr1 + pr5)/ pr4);
        
        System.out.println("out of 10 bombs chosen the probability" +
        " that no more than 1 is defective" + (1 - (pr1 + pr5) / pr4));
        
        double br1 = binom(0,15,.075);
        double br2 = binom(1,15,.075);
        double br3 = binom(2,15,.075);
        double br4 = br1 + br2 + br3;
        
        
        System.out.println("15 taken from a very large portion of" +
        " hand grenades where at most two are defective is " + br4);
        
        
   
   }//end main

}//end class