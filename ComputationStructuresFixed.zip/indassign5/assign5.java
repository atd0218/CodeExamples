//Ashton Daniels
//CS 2130 - 11:30am
//Individual Assignment 5
//Dr Huson.
//Due 04/04/2019
//Filename: assign4.java


/*
this program allows input for 2 differnt matrices, then it will list
them as well as list the meet, join, product, complement, 
transpose, reflexive relation, symmetric relation, 
transitive relation. 
*/
//import files
import java.util.*;
import java.io.*;

public class assign5
{   
   public static void main (String[]args)
   {
   
      //variables
      int[][] matrix = new int[3 + 1][3 + 1];
      int[][] matrix2 = new int[3 + 1][3 + 1];
      int row = 0;
      int column = 0;
      int row2 = 0;
      int column2 = 0;
      
      //scanner initialization
      Scanner in = new Scanner(System.in);
      
      //initialize matrix to all zeroes
      for(int i = 0; i < 3; i++)
      {
         for(int j = 0; j < 3; j++)
         {
            matrix[i][j] = 0;
            matrix2[i][j] = 0;
         }
      }
      
      
      
      // for loops to enter input of ordered pairs
      System.out.println("Please enter first set of ordered pairs");
      for(int i = 1; i < 10; i++)
      {
         row = in.nextInt();
         column = in.nextInt();
         matrix[row][column] = 1;
            
         if(row == 0)
         {
            if(column == 0)
            {
               break;
            }
         }
       }// second for end
      
      System.out.println("Please enter second set of ordered pairs");
      for(int i = 1; i < 10; i++)
      {
         row2 = in.nextInt();
         column2 = in.nextInt();
            
         matrix2[row2][column2] = 1;
            
         if(row2 == 0)
         {
            if(column2 == 0)
            {
               break;
            }
         }
      }// second for end
      
      
      //printing out matrix's
      System.out.println("Matrix A =");
      for(row = 1; row < 4; row++)
      {
         for(column = 1;column < 4; column++)
         {
            System.out.print(matrix[row][column] + " ");
            
         }
         System.out.println();
      }
      
      System.out.println("Matrix B =");
      for(row2 = 1; row2 < 4; row2++)
      {
         for(column2 = 1; column2 < 4; column2++)
         {
            System.out.print(matrix2[row2][column2]+ " ");
         }
         System.out.println();
      }
      
     //meet function
     int meet[][] = new int[3 + 1][3 + 1];
     for(int i = 1; i < 4; i++)
     {
        for(int j = 1; j < 4; j++)
        {
            if(matrix[i][j] == 1 && matrix2[i][j] == 1)
            {
               meet[i][j] = 1;
            }
            if(matrix[i][j] == 1 && matrix2[i][j] == 0)
            {
               meet[i][j] = 0;
            }
            if(matrix[i][j] == 0 && matrix2[i][j] == 1)
            {
               meet[i][j] = 0;
            }
        }
     }
     
     System.out.println("A Meet B : ");
     //printing meet function
     for(int i = 1; i < 4; i++)
     {
         for(int j = 1; j < 4; j++)
         {
            System.out.print(meet[i][j] + " ");
         }
         System.out.println();
     }  


     //join function
     int[][] join = new int[3 + 1][3 + 1];
     for(int i = 1; i < 4; i++)
     {
         for(int j = 1; j < 4; j++)
         {
            if(matrix[i][j] == 1 && matrix2[i][j]	==	1)
		      {
			      join[i][j]	= 1;
		      }
		      if(matrix[i][j] == 1 && matrix2[i][j]	==	0)
		      {
			      join[i][j]	= 1;
		      }
		      if(matrix[i][j] == 0 && matrix2[i][j]	==	1)
		      {
			      join[i][j]	= 1;
		      }
		      if(matrix[i][j] == 0 && matrix2[i][j]	==	0)
		      {
			      join[i][j] = 0;
		      }

         }
      }
     
     System.out.println("A Join B : ");
     //print join function
     for(int i = 1; i < 4; i++)
     {
         for(int j = 1; j < 4; j++)
         {
            System.out.print(join[i][j] + " ");
         }
         System.out.println();
     } 
     
     //product function
     int product[][] = new int[3 + 1][3 + 1];
     for(int i = 1; i < 4; i++)
     {
         for(int j = 1; j < 4; j++)
         {
           product[i][j] = 0;
           for(int k = 1; k < 4; k++)
           {
               product[i][j] |= matrix[i][k] & matrix2[k][j];
           }
           
         }
     }
     System.out.println("A Product B : ");
     //print product function
     for(int i = 1; i < 4; i++)
     {
         for(int j = 1; j < 4; j++)
         {
            System.out.print(product[i][j] + " ");
         }
       System.out.println();
     }


     //complement function
     int complement[][] = new int[3 + 1][3 + 1];
     for(int i = 1; i < row; i++)
     {
         for(int j = 1; j < column; j++)
         {
            if(matrix[i][j] == 1)
            {
               complement[i][j] = 0;
            }
            else
            {
               complement[i][j] = 1;
            }
         }
     } 
     
     System.out.println("Complement Of A : ");
     //printing complement function
     for(int i = 1; i < row; i++)
     {
         for(int j = 1; j < column; j++)
         {
            System.out.print(complement[i][j] + " ");
         }
         System.out.println();
     }  
   
     
      
     //transpose function 
     int transpose[][] = new int[3 + 1][3 + 1];
     for(int i = 1; i < row; i++)
     {
         for(int j = 1; j < column; j++)
         {
            transpose[j][i] = matrix[i][j];
         }
     }  
     
     System.out.println("Transpose Of A : ");
     //printing transpose function   
     for(int i = 1; i < row; i++)
     {
         for(int j = 1; j < column; j++)
         {
            System.out.print(transpose[i][j] + " ");
         }
         System.out.println();
     } 
     
     //reflexive function
     int reflexive[][] = new int[3 + 1][3 + 1];
     for(int i = 1; i < 4; i++)
     {
         for(int j = 1; j < 4; j++)
         {
            if(matrix[1][1] == 1 || matrix[2][2] == 1 || matrix[3][3] == 1)
            {
               reflexive[1][1] = 1;
               reflexive[2][2] = 1;
               reflexive[3][3] = 1;
            }
           
         }
     }
     
     System.out.println("Reflexive Relation On F Containing A : ");
     //print reflexive function
     for(int i = 1; i < 4; i++)
     {
         for(int j = 1; j < 4; j++)
         {
            System.out.print(reflexive[i][j] + " ");
         }
         System.out.println();
     }
     
     
     //symmetric funtion
     int symmetric[][] = new int[3 + 1][3 + 1];
     for(int i = 1; i < 4; i++)
     {
         for(int j = 1; j < 4; j++)
         {
            if(matrix[1][2] == 1 || matrix[2][1] == 1)
            {
               symmetric[1][2] = 1;
               symmetric[2][1] = 1;
            }
            if(matrix[1][3] == 1 || matrix[3][1] == 1)
            {
               symmetric[1][3] = 1;
               symmetric[3][1] = 1;
            }
            if(matrix[2][3] == 1 || matrix[3][2] == 1)
            {
               symmetric[2][3] = 1;
               symmetric[3][2] = 1;
            }
         }
     }
     
     System.out.println("Symmetric Relation On F Containing A : ");
     //print symmetric function
     for(int i = 1; i < 4; i++)
     {
         for(int j = 1; j < 4; j++)
         {
            System.out.print(symmetric[i][j] + " ");
         }
         System.out.println();
     } 
     
     //transative closure
     int transative[][] = new int[3 + 1][3 + 1];
     for(int k = 1; k < 4; k++)
     {
         for(int i = 1; i < 4; i++)
         {
            for(int j = 1; j < 4; j++)
            {
               transative[i][j] = matrix[i][j] | (matrix[i][k] & matrix[k][j]);
            }
         }
     }
     
     System.out.println("Transative Relation On F Containing A : ");
     //print transative closure
     for(int i = 1; i < 4; i++)
     {
         for(int j = 1; j < 4; j++)
         {
               System.out.print(transative[i][j] + " ");
         }
         System.out.println();
     }
      
      
     


   }//end main
}//end class