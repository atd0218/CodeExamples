import java.util.Scanner;

public class StringFun
{


   public static void main (String[] args)
   {
   
      Scanner in = new Scanner (System.in);
      
      String sentence = "";
      char ch = ' ';
      System.out.println("Please enter a sentence.");
      sentence = in.nextLine();
      
      for (int i = 0; i < sentence.length(); i++)
      {
      
         ch = sentence.charAt(i);
         
         
         if (ch != 'i')
         {
            System.out.print(ch);
         }
         
      
      }
     
      
      
   
   
   }



}