/***********************************************************
* Identifiers cant be numbers or pre saved java words
* numbers can be used if you have a letter first
* can use special characters (_,$)
*
*
*
*
***********************************************************/
public class VariableIdentifierFun
{

   public static void main (String[] args)
   {
   
   
      int BuildingHeight;
   
      
   
   }



}