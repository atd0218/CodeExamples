public class Citizen
{
   String SSN = "";
   
   public Citizen (String s) // constructor method cant return anything only contains things taht need set up 
   {//constructors have to have the same name as the class
   
      this.SSN = s;
        
   }

}