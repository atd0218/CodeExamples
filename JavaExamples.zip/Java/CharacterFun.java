public class CharacterFun
{

   public static void main (String[] args)
   {
   
      char ch = '9';
      
      if (Character.isDigit(ch))
      {
      
         System.out.println("Yes, this is a number.");
         
      }
      else
      {
         System.out.println("NO this is no number.");
      }
   
   }


}