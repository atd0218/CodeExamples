import java.util.*;

public class ExceptionHandlingFun
{

   public static void main (String[]args)
   {
      Scanner in = new Scanner (System.in);
      
      int shoeSize = 0;
      boolean error = false;
    
    
      String[] placesMyOfficeIsHotterThan = {"Molten Lava" , "The Sun" , "Texas in July" ,
         "The Cornballer" , "Hell"};
      
      
      
      System.out.println("What is your shoe size?");

    do
    {
       try
       {  
         error = false;
         
         shoeSize = in.nextInt();
         
        // System.out.println("My office is hot. How hot is it?");
         //System.out.println("It is hotter thatn...");
         
        // for (int i = 0; i <= 5; i++)
         //{
           // System.out.println(placesMyOfficeIsHotterThan[i]);
         //}
      
       }
       catch (InputMismatchException e)
       {
         error = true;
         System.out.println(e.getMessage());
         System.out.println("Sorry, that was not valid input.");
         System.out.println("Please enter shoe size using numbers.");
         
         //flush the buffer
         in.nextLine();
         
      
       } 
       catch (ArrayIndexOutOfBoundsException e)
       {
         System.out.println(e.getMessage());
       
       }
       catch (Exception e)
       {
         System.out.println(e.getMessage());
       }
    }while(error);  
   }//end main 
   

}//end class