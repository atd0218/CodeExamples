/************************************************
* java is made for small programs, so if we need something large
we have to import it as shown below. import is always befor class name
* Scanner in = new Scanner (System.in) this line shows how we access
that import we used at the beginning
* when you use in.nextLine it is designed only to read in text
* when you use in.nextDouble you can store numbers
* in.nextInt can also store a number
* if you just us in.next it will read the next word to the next space instead
of the whole line
*
************************************************/
import java.util.Scanner;

public class InputFun
{
   public static void main (String[] args)
   {
      
      Scanner in = new Scanner (System.in); 
      
/*******************************************************
* you can replace if with while if you want it to keep doing it over
and over and over again. 
* for loop is when we know how many times it will take
* do loop is to let it go as many times as needed
* while loop has conditions while  (Guess != #)
*Create the program  first as if you have one chance then put the 
loops in 
*
*******************************************************/      
      
      String name = "";
      double weight = 0.0;
      int age = 0;
      
      // Get user name to print greeting
      System.out.println(" Please enter your name");
      name = in.nextLine(); 
      // Print Greeting 
      System.out.println("Hello, " + name);
      
      //Check the weight
      System.out.println("How much do you weight");
      weight = in.nextDouble();
      
      System.out.println("weight: " + weight);
      
      // check age
      System.out.println("How old are you");
      age = in.nextInt();
      System.out.println("Age: " + age); 
      
      
        
   }

}