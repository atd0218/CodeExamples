import java.util.Scanner;
import java.util.Random;

public class MissionFiveAssignment
{

   public static void main (String[] args)
   {
      
      Scanner in = new Scanner (System.in);
      Random r = new Random();
      
      String userChoice = "";// initializing userChoice
      String cpuChoice = "";// initializing cpuChoice
      int userWins = 0;// initializing userWins
      int cpuWins = 0;// initializing cupWins
      int number = 0; // generated number which translate to Rock Paper Scissors
      int numGames = 0; // number of games user wants to play
      
      //Greet user
      System.out.println("Welcome to Rock Paper Scissors Game!");
      // get number of games to play from user
      System.out.println("How many games would you like to play?");
      numGames = in.nextInt();
      while (numGames%2 == 0)
      {
         System.out.println("Invalid choice, please try again.");
         numGames = in.nextInt();
      }
      
      //flush the buffer
      in.nextLine();
      
      //play game for number of games user chose
      for ( int i = 1; i <= numGames; i++)
      {
         // Ask user to choose rock paper scissors
         System.out.println("Please choose Rock, Paper, or scissors");
         userChoice = in.nextLine();
         
         //check for valid input
         
         while(!userChoice.equalsIgnoreCase("Rock") && !userChoice.equalsIgnoreCase("Paper") && !userChoice.equalsIgnoreCase("Scissors"))
         {
            System.out.println("Sorry, that is an invalid choice. Please try again!");
            userChoice = in.nextLine();
         
         }
      
      
         //Generate a number
         // set cpuchoice
         // print cpuchoice
         number = r.nextInt(3);
         if(number == 0)
         {
            cpuChoice.equalsIgnoreCase("Rock");
            System.out.println("CPU chose Rock");
            cpuChoice = in.nextLine();
            
         } 
         
         if(number == 1)
         {
            cpuChoice.equalsIgnoreCase("Paper");
            System.out.println("CPU chose Paper");
            cpuChoice = in.nextLine();
            
         }
         
         if(number == 2)
         {
            cpuChoice.equalsIgnoreCase("Scissors");
           System.out.println("CPU chose Scissors");
           cpuChoice = in.nextLine();
         }
         
         
         
         
         
         
         // conditional statements stating whether user or cpu wins
         if( (userChoice.equalsIgnoreCase("Rock") && cpuChoice.equalsIgnoreCase("Scissors")) || (userChoice.equalsIgnoreCase("Paper") && cpuChoice.equalsIgnoreCase("Rock")) || (userChoice.equalsIgnoreCase("Scissors") && cpuChoice.equalsIgnoreCase("Paper")))
         {
            System.out.println("You Win!");
            userWins ++;
            
         
         }
         if((userChoice.equalsIgnoreCase("Rock") && cpuChoice.equalsIgnoreCase("Paper")) || (userChoice.equalsIgnoreCase("Paper") && cpuChoice.equalsIgnoreCase("Scissors")) ||(userChoice.equalsIgnoreCase("Scissors") && cpuChoice.equalsIgnoreCase("Rock")))
         {
            System.out.println("CPU Wins!");
            cpuWins++;
         
         }
         if(userChoice.equalsIgnoreCase(cpuChoice))
         {
            System.out.println("It's a draw");
         }
      }
      
      //print results
         System.out.println("User won " + userWins + " times " + " Computer won " + cpuWins + " times ");
   
   }// end main 



} // end class