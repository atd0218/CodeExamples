public class MathClassFun
{

   public static void main (String[] args)
   {
   
      double x = 0;
      
      x = 13.3/7.8;
      
      x = Math.ceil(x);
      
      System.out.println(x);
   
   
   }

}