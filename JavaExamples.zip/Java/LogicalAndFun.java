/****************************************************
* when using logical statements you will use && for AND
*
*
*
*
*
****************************************************/
public class LogicalAndFun
{

   public static void main (String[] args)
   {
      // && = AND
      int heightInInches = 100;
      String name = "Sam";
      
      if (heightInInches >= 48 && heightInInches < 84)
      {
           System.out.println("You can ride!");

         
      }
      else
      {
         System.out.println("Sorry you cant ride");
      
      }
      
   
   
   }


}