import java.util.Scanner;
import java.util.Random;

public class MissionSevenAssignment
{

   public static void main(String[]args)
   {
      
      int userPick = 0;
      int[] tally = new int[13];
      int roll = 0;
      int roll2 = 0;
      int numAsterisks = 0;
      int numRolls = 0;
      int rollResult = 0;
      
      
      
      Scanner in = new Scanner (System.in);
      Random r = new Random();
     
      
      System.out.println("Welcome to the dice roll simulator!");
      
      // ask user how many times he would like to roll 
      System.out.println("How many times would you like to roll");
      userPick = in.nextInt();
      numRolls = userPick;
      
      // simulate the roll of the dice
      for (int i = 0; i < numRolls; i++)
      {
         //roll the dice
         roll = r.nextInt(6)+1;
         roll2 = r.nextInt(6)+7;
         rollResult = roll + roll2;
         
         tally[roll]++;
         tally[roll2]++;
         
      }// end for
      
      //Print results
      for (int i = 2; i < tally.length; i++)
      {
         numAsterisks = 100 * tally[i] / numRolls;
         
         System.out.println((i) + ": " + numAsterisks);
         
         
      
      }// end for
      
      //Histogram
      //for (int i = 2; i < numAsterisks; i++)
      //{
         
        // System.out.println((i) + ": " + "*");
      
      //}
      
      
      
      
        
   }// end main method 


}// end class