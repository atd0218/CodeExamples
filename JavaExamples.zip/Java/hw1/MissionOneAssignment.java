/*********************************************
* MissionOneAssignment.java
* Ashton Daniels
*
* I coded my first program with no help
**********************************************/

public class MissionOneAssignment 
{

   public static void main (String[] args)
   {
   
      System.out.println("My name is Ashton Daniels");
      System.out.println("My favorite movie is Just Go WIth It");
   
   }

}