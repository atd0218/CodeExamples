import java.util.ArrayList;

public class arrayListFun
{

   public static void main (String[]args)
   {
   
      ArrayList<String> bands = new ArrayList<String>();
      
      bands.add("The Beatles");
      bands.add("Led Zepplin");
      bands.add("The Eagles");
      bands.add("Credence");
      bands.add("Queen");
      
     
      
      System.out.println(bands);
      
      bands.remove(2);
      
      System.out.println(bands);
      
     
      
      if (bands.indexOf("The Beatles") !=0)
      {
      
         System.out.println("You're Crazy!");
      }
   
   }




}