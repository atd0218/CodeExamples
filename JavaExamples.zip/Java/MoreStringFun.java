import java.util.Scanner;

public class MoreStringFun
{

   public static void main (String[] args)
   {
      int firstSpace = 0;
      int secondSpace = 0;
      
      Scanner in = new Scanner (System.in);
      
      
      String sentence = ("It's the final countdown!");
      String secondWord = "";
      
      firstSpace = sentence.indexOf(' ');
      secondSpace = sentence.indexOf(' ' , firstSpace+1);
      
      System.out.println(firstSpace);
      System.out.println(secondSpace);
      
      secondWord = sentence.substring((firstSpace+1),secondSpace);
      
      secondWord = secondWord.toUpperCase();
      
      System.out.println("The second word is \"" + secondWord + "\".");
   
   }

}