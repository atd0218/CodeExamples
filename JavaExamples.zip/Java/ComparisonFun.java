/*******************************************
* when using If always put = sign at end of your comparison
* when using IF statements if you are saying not equal to it will be (!=)
*
*
*
*
*******************************************/

public class ComparisonFun
{

   public static void main (String[] args)
   {
   
      int a = 4;
      int b = 8;
      int c = 15;
      int d = 16;
      int e = 23;
      int f = 42;
      
      if (a != 4)
      {
            System.out.println("Yes!");
      
      }
      else
      {
         System.out.println("No!");
      
      }
      
      // >, <, >=, <=, ==, !=
   
   }


}