/*************************************************
* when comparing String statements you must type out .equals instead of ==
* if you are comparing Sring statements and you want java to Ignore case sensitive
letters then you must type equalsIgnoreCase
* if you want a not you will still put an ! in front of comparison
*
*
**************************************************/
public class StringComparisonFun
{

   public static void main (String[] args)
   {
   
         String text = "Word";
      
         if (!text.equals("Word"))
         {
         
            System.out.println("Yes");
         
         }
         else
         {
         
            System.out.println("No");
         
         }
      
      
      
      
   
   
   
   }




}