/********************************************************
* if you want to combine a println with variable you use concatenation
concatenation symbol is a +
*when using concatenation if it is stuck together make sure to space after your
String
*
*
*
*
********************************************************/
public class VariableFun
{

   public static void main (String[] args)
   {
   
      
         int age = 25;
         
         System.out.println("I am " + age + " years old.");
         
   
   
   }



}

