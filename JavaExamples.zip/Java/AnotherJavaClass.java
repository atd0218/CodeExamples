public class AnotherJavaClass {

   public void printsomething () {
   
      System.out.println("Hello, world"); 
      
      
   
   
   }

}