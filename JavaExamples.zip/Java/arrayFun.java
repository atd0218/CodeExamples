public class arrayFun
{
   public static void main (String[] args)
   {
      String[][] students = new String[10][2];
      students[0][0] = "Michael";
      students[0][1] = "Bluth";
      
      students[1][0] = "Lindsay";
      students[1][1] = "Bluth";
      
      students[2][0] = "Rob";
      students[2][1] = "Bluth";
      
      students[3][0] = "George Michael";
      students[4][0] = "Maeby";
      students[5][0] = "Tobias";
      students[6][0] = "Buster";
      students[7][0] = "George";
      students[8][0] = "Lucille";
      students[9][0] = "Lucille 2";
      
      for ( int i =0;i < students.length; i++)
      {
         for(int j = 0; j < 2; j++)
         {
            System.out.print(students[i][j]);
         }
      }
   
   // arrays have to be same type of variable 
   // if you originally store 100 elements you cant use any more 
   // declare array using int[] = new int[25];
   
   }

   


}