import java.util.Scanner;

public class MethodFun
{

   public static void main (String[] args)
   {
     Scanner in = new Scanner (System.in);
     
     int number = 0;
      
     int squaredNumber = 0;
     
     System.out.println("which number would you like to be squared?");
     number = in.nextInt();
     
     square(number);
     
     System.out.println(square(number));
   
        
   
   
   }
   
   public static int square (int number)
   {
   
      int result = 0;
      
      result = number * number;
      
      return result;
   
   }




}