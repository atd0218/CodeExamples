import java.util.Scanner;

public class MissionTwoAssignment
{

   public static void main (String[] args)
   {
   
      Scanner in = new Scanner (System.in);
      
      int dayBorn = 0;
      int yearBorn = 0;
      String month = "";
      int retirementYear = 0;
      
      // asking the users birth month 
      System.out.println("Please enter the month you were born:");
      month = in.nextLine();
      
      // ask the user the day they were born 
      System.out.println("Please enter the day you were born:");
      dayBorn = in.nextInt();
      
      // ask the user the year they were born
      System.out.println("Please enter the year you were born:");
      yearBorn = in.nextInt();
      
      // retirement year 
      retirementYear = (yearBorn + 67);
      
      // tell the age they will retire 
      System.out.println("You will retire on " + month + " " + dayBorn + " " + retirementYear );
      
      
   }  




}