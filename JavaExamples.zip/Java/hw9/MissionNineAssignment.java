import java.util.*;
import java.io.*;


public class MissionNineAssignment
{

   public static void main (String[] args)
   {
      File f;
      Scanner in = new Scanner(System.in);
      String userChoice = "";
      Scanner Filein;
      String fileName = "";
      
      
         
   
   
   }//end main 



}//end class