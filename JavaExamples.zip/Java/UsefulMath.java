public class UsefulMath
{

    
   public static int square (int number)
   {
   
      int result = 0;
      
      result = number * number;
      
      return result;
   
   }
   
    public static int power (int num, int pow)
   // you can pass in multiple things it does 
   // not have to be an integer 
   // order matters make sure your consistent
   {
   
      int result = num;
      
      for (int i = 1; i < pow; i++)
      {
         result = result * num;
      }
      
      return result;
   
   }


}