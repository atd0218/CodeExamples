import java.util.*;

public class RockPaperScissors
{
        
   public String getUserChoice()
   {
      Scanner in = new Scanner (System.in);
      String userChoice = "";
      
      // prompt user for choice
      
      System.out.println("Please choose Rock, Paper, or Scissors");
      userChoice = in.nextLine();
      
      // validate choice
      while (!userChoice.equalsIgnoreCase ("Rock") && !userChoice.equalsIgnoreCase ("Scissors") && !userChoice.equalsIgnoreCase ("Paper"))
      {
         System.out.println("Invalid Input Please try again!");
         userChoice = in.nextLine();
      
      }
      
      
   
      return userChoice;
   }// end user choice method 
   
   public String getCPUChoice()
   {
      Random r = new Random();
      String CPUChoice = "";
      int number = 0;
      
      // generate a random number
      r.nextInt(3);
      
      // Conditional statements
      
      if(number == 0)
      {
         CPUChoice = "Rock";
      }
      
      if (number == 1)
      {
         CPUChoice = "Paper";
      }
      
      if (number == 2)
      {
         CPUChoice = "Scissors";
      }
      
      return CPUChoice;
      
   
   
   }// end CPUChoice
   
   public String pickWinner(String userChoice, String cpuChoice)
   {
      String winner = "";
      
      if ( userChoice.equalsIgnoreCase (cpuChoice))
      {
         winner = "Tie";
      }
      if (userChoice.equalsIgnoreCase("Rock") && cpuChoice.equalsIgnoreCase("Paper")|| userChoice.equalsIgnoreCase("Paper") && cpuChoice.equalsIgnoreCase("Scissors") || userChoice.equalsIgnoreCase("Scissors") && cpuChoice.equalsIgnoreCase("Rock"))
      {
         winner = "CPU";
      }
      if (userChoice.equalsIgnoreCase("Paper") && cpuChoice.equalsIgnoreCase("Rock") || userChoice.equalsIgnoreCase("Scissors") && cpuChoice.equalsIgnoreCase("Paper") || userChoice.equalsIgnoreCase("Rock") && cpuChoice.equalsIgnoreCase("Scissors"))
      {
         winner = "User";
      }
   
    return winner;
   }// end pickWinner



}// end class