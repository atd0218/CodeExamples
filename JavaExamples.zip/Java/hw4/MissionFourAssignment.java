import java.util.Scanner;

public class MissionFourAssignment
{

   public static void main (String[] args)
   {
   
      Scanner in = new Scanner (System.in);
      String userWord = ""; // word the user will enter
      String pigWord = ""; // word that will be translated
      char ch = ' '; // temp char holder
            
      System.out.println("Welcome to the pig latin translator.");
      
      // Ask user to enter a word
      System.out.println("Please enter a word!");
      userWord = in.nextLine();
      
      // check first letter decide if its a vowel
      do
      {
         // get first character
         ch = userWord.charAt(0);
         
         if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u')
         {
            System.out.println((userWord) + "way");
         }
         else // this is if it's a constinent 
         {
            for( int i = 0; i < userWord.length(); i++)
            {
               ch = userWord.charAt(i);
               
               if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u')
               {
                  System.out.println(userWord.substring(i) + userWord.substring(0,i) + "ay");
                  break;
               }              
            }
         }  
         
         

         
      
      
      
      // Ask user to enter another word or press Q 
      System.out.println("Please enter another word, or press Q to quit");
      userWord = in.nextLine();
      
      }while (!userWord.equalsIgnoreCase("Q"));
   
   
   }



}