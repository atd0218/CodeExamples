/************************************************
* major problem object oriented prgramming solves will be to conserve space
this will help us to split it up 
*
*They program this way now so people can work in teams to accomplish
one program 
*
*
*
*************************************************/

import java.util.*;

public class ObjectFun
{
   public static void main (String[] args)
   {
   
         Random r = new Random();   
         int die1 = 0;
         int die2 = 0;
         int total = 0;
         int numWins = 0;
         int numLoss = 0;
         
         //Simulate roll of dice
         for (int i = 0; i<1000000; i++)
         {
         
            die1 = r.nextInt(6)+1;
            die2 = r.nextInt(6)+1;
            
            total = die1 + die2;
            
           // System.out.println("The total roll was: " + total);
            
            //Decide whether they win
            if (total == 7 || total == 11)
            {
               //System.out.println("You win!");
               numWins++;
            
            }
            else
            {
              // System.out.println("You Lose!");
               numLoss++;
            }
            
         }// end for
         
         //Print results
         System.out.println("Wins: " + numWins);
         System.out.println("Losses: " + numLoss);
   
   }//end main 






}//end class