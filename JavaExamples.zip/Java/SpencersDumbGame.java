public class SpencersDumbGame
{

   public static void main (String[] args)
   {
      Dice d = new Dice();
      
      
      
      int total = 0;
      
      int numWins = 0;
      int numLoss = 0;
      //Simulate the roll of the dice 1000 times
      for (int i = 0; i < 1000; i++)
      {
         //rolling the dice
         total = d.rollDice(2);
         
         
         
         if ( total == 7 || total == 11)
         {
         
            numWins++;
         
         }
         else
         {
            numLoss++;
         
         }
      
      }// end for
      
      //Print results 
      System.out.println("Wins: " + numWins);
      System.out.println("Losses: " + numLoss);
   
   
   }// end main 


}//end class