/*************************************************
* if you want to use greater than or equal to in if statement you use >=
* If/Else statements are used if you need its either this or that
*
*
*************************************************/

import java.util.Scanner;

public class IfElseFun
{

   public static void main (String[] args)
   {
   
      Scanner in = new Scanner (System.in);
      
      int age = 0;
      
      System.out.println("How old are you?");
      age = in.nextInt();
      
      if (age >= 40)
      {
         System.out.println("You are over the hill!");
      
      }
      else 
      {
         System.out.println("You are working your way up the hill");
      
      }
   
   
   
   }



}