import java.util.Scanner;
import java.util.Random;

public class OddEvenGame
{

   public static void main (String[] args)
   {
   
      Scanner in = new Scanner (System.in);
      Random r = new Random ();
      
      int numGames = 0;
      String userCall = ""; // user calls odd or even and result
      int userThrow = 0; //user throws odd or even which will be determined
      int cpuThrow = 0;
      int userWins = 0;
      int cpuWins = 0;
      int throwTotal = 0;
      boolean isOdd = false;// true = odd false = even
      
      // get the number of games to play from user
      System.out.println("How many games do you want to play?");
      numGames = in.nextInt();
      
      //Flush the buffer
      in.nextLine();
      
      // play game for number of times user specified
      for (int i = 1; i <= numGames; i++)
      {
         System.out.println("Call it: Odd or Even?");
         userCall = in.nextLine();
       
         // check for valid input
         while(!userCall.equalsIgnoreCase("odd") && !userCall.equalsIgnoreCase("even"))
         {
            System.out.println("Sorry, that is not a valid choice. Try again!");
            userCall = in.nextLine();
         
         }
         
       // ask for throw
       System.out.println("Do you want to throw a 1 or a 2?");
       userThrow = in.nextInt();
       
       //check for valid input
         while(userThrow != 1 && userThrow != 2)
         {
       
          System.out.println("You need to select 1 or 2! Try again");
          userThrow = in.nextInt();
         }
       
       // make a random choice for the computer
         cpuThrow = r.nextInt(2) + 1;
       
       // decide whether it is even or odd number
         throwTotal = userThrow + cpuThrow;
       
         if(throwTotal == 2 || throwTotal ==4)
         {
            isOdd = false;
       
         }
         if(throwTotal == 3)
          {
          isOdd = true;
          }
       
       // Decide who wins round
         if ((userCall.equalsIgnoreCase("odd") && isOdd) 
            || userCall.equalsIgnoreCase("even") && !isOdd)
         {
            System.out.println("User Wins!");
            userWins++;
         
         }
         if(userCall.equalsIgnoreCase("even") && isOdd
            || userCall.equalsIgnoreCase("odd") && !isOdd)
         
         {
            System.out.println("Computer Wins!");
            cpuWins++;
      
         }
      
      }//end for 
       
       
       
      
   
   
   }//end main



}// end class