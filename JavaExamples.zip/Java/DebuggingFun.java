import java.util.Scanner;

public class DebuggingFun
{
   public static void main (String[] args)
   {
   
      Scanner in = new Scanner (System.in);
      
      double weightinPounds = 0.0;
      double weightinKilos = 0.0;
      
      // ask user for their weight
      System.out.println("Please enter your weight (in lbs)");
      weightinPounds = in.nextDouble();
      
      // convert lbs to kilos
      weightinKilos = convertToKilos(weightinPounds);
      
      // Print results
      System.out.println(weightinPounds + " lbs is " + weightinKilos + "kgs");
      
      if (weightinPounds > 1000)
      {
         System.out.println("Have you thought about contacing guinness");
      }
       
   }

}

public static double convertToKilos (double p)
{
  double result = 0.0;
  //Calculate weight in kilos
  result = p * 0.453592
  
  return result;
   


}