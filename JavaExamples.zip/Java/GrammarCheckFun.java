import java.util.Scanner;

public class GrammarCheckFun
{

   public static void main (String[] args)
   {
   Scanner in = new Scanner (System.in);
   String userSentence = ""; // this is original sentence
   String correctSentence = ""; // sentence with corrections
   char ch = ' '; // temp character holder
   
   
   // ask user to enter a sentence
   System.out.println("Please enter a sentence.");
   userSentence = in.nextLine();
   
   // check sentence, correct errors, allow user to enter again 
   do 
   {
      // get the first character and make it upper case
      ch = userSentence.charAt(0);
      ch = Character.toUpperCase(ch);
      
      correctSentence = Character.toString(ch);
      
      // Copy in rest of sentence
      correctSentence = correctSentence + userSentence.substring(1);
      
    
      
      // Check to make sure last character is punctuation character
      ch = correctSentence.charAt(userSentence.length()-1);
      
          if (ch != '.' && ch != '?' && ch != '!')
         {
            correctSentence = correctSentence + ".";
      
         }
      
         //Print Correct sentence
      
          System.out.println("Corrected Sentence: " + correctSentence);
    
      
          // Allow user to quit or enter another sentence
          System.out.println("Enter another sentence or press Q to quit");
         userSentence = in.nextLine();
      } while (!userSentence.equalsIgnoreCase("Q"));
   
   
    }
}