public class MyFirstProgram {

   public static void main (String[] args) {
   
      AnotherJavaClass x = new AnotherJavaClass();
      
      x.printsomething();
   
   
   }
   


}