/**********************************************
*you only flush the buffer when your going from a number to a sentence
if you go from and int to a line or a double to a line
*
*
*
**********************************************/

import java.util.Scanner;

public class FlushTheBufferFun
{

   public static void main (String[] args)
   {
   
      Scanner in = new Scanner (System.in);
      
      String name = "";
      double gpa = 0.0;
      String year = "";
      
      // get info from student
      System.out.println("Please enter your name");
      name = in.nextLine();
      
      System.out.println("What is your GPA");
      gpa = in.nextDouble();
      
      //Flush the buffer
      in.nextLine();
      
      System.out.println("What year are you in school?");
      year = in.nextLine();
   
   
   
   
   }
   

}