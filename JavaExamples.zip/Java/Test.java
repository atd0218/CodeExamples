public class Test
{
   public static void main (String[] args)
   {
          double dollarValue = 1.00; 
 
      if (dollarValue != 2.00); 
      { 
         System.out.println("I want my two dollars!"); 
      }   
          
   } 
  


}