/**********************************************************
* Conditional statements = if, if/else, if/else if,  while, do
*when using one you start with the key word then put () what goes in the parenthesis
is what condition you are trying to meet 
* you have to use 2 equal signs to compare something in your if statement
*
*
**********************************************************/


import java.util.Scanner;

public class IfFun
{

   public static void main (String[] args)
   {
      
      Scanner in = new Scanner (System.in);
      
      int age = 0;
      
      System.out.println("How old are you?");
      age = in.nextInt();
      
      if (age == 25)
      {
      
         System.out.println("Love that age!");
      }
   
   
   
   }



}