public class Sniper extends BaseSoldier
{
   private int range = 700;
   
   
}