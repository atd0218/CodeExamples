public class MathFun
{

   public static void main(String[] args)
   {
      
      // % sign = modulus operator
      
      int a = 28;
      int b = 6;
      
      int total = 0;
      
      total = a % b;
      
      System.out.println(total);
   
   }


}