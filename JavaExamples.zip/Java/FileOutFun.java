import java.io.*;

public class FileOutFun
{

   public static void main (String[] args)
   {
      try
      {
         PrintWriter fileOut = new PrintWriter("C:\\java\\output.txt");
         
         fileOut.println("Just printed some text to a file.");
         fileOut.print("Oh i am the shit man!");
         fileOut.close();
      
      }
      catch (FileNotFoundException e)
      {
         System.out.println("Sorry not a valid file.");
      }
   }




}