import java.util.Scanner;

public class TwoRedo
{

   public static void main (String[] args)
   {
   
      Scanner in = new Scanner (System.in);
      
      String month = "";
      int day = 0;
      int year = 0;
      
      System.out.println("Please enter the month you were born:");
      month = in.nextString();
   
   
   
   }



}