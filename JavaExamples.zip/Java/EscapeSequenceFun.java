/**************************************************
* Escape Sequences are used for java to intepret
Escape Sequence symbol = \ that means whatever come next will tell you what to do 
* for example if you want a word in quotes it would be \"love\"
* println makes it print each individual line
* if you \n that means the text following would transfer to a new line
* if you \t it will move it to the next tab location 
*
*
**************************************************/
public class EscapeSequenceFun
{

   public static void main (String[] args)
   {
     
     System.out.println("I really \"love\" these videos."); 
     System.out.println("I want the next text \tto go on the next line.");
     
     
     
   }





}