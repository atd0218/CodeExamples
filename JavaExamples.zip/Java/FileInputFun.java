import java.util.*;
import java.io.*;

public class FileInputFun
{

   public static void main (String[] args)
   {
      try
      {
         File f = new File ("C:\\java\\blah.txt");
         Scanner fileIn = new Scanner (f);
         
         
         String line = "";
         String word = "";
         int count = 0;
         // .hasnext method lets us make sure something is there first
        
         while (fileIn.hasNext())
         {
            word = fileIn.next();
            count++;  
           
         } 
         System.out.println("# words: " + count);      
        
        
        // line = fileIn.nextLine();
      
         //System.out.println(line);
         
         //line = fileIn.nextLine();
         //System.out.println(line);
      }
      catch (FileNotFoundException e)
      {
      
         System.out.println("Sorry, bad file name!");
      
      }
   
   }





}