import javax.swing.*;
import java.awt.*;

public class Home
{
    JFrame homeScreen;
    JLabel userInfo;
    JTextField txtName;
    JButton btnOK;
      

   //Constuctor means method called when needing this home stuff
   public Home ()
   {
        homeScreen = new JFrame();
        homeScreen.setSize(400,200);
        homeScreen.setTitle("build my box bitch");
        homeScreen.setDefaultCloseOperation(homeScreen.EXIT_ON_CLOSE);
        homeScreen.setLayout(new FlowLayout());
        
        
        userInfo = new JLabel("Enter your name:");
        txtName = new JTextField(20);
        btnOK = new JButton("OK");
        
        homeScreen.add(userInfo);
        homeScreen.add(txtName);
        homeScreen.add(btnOK);
        homeScreen.setVisible(true);
   }


}


  /**********
        //frame configuration
        homeScreen.setSize(400,200);  //width first then height in parenthesis
        homeScreen.setDefaultCloseOperation(homeScreen.EXIT_ON_CLOSE);
        homeScreen.setTitle("build my box bitch"); // also can set title there
        homeScreen.setLayout(new FlowLayout());// layouts must be by frame
       
        
        JLabel userInfo = new JLabel ("Please enter name:"); // displays stuff user should know 
        homeScreen.add(userInfo);
        
        JTextField txtname = new JTextField(20);
        homeScreen.add(txtname);
        
        JButton btnOK = new JButton("OK");
        homeScreen.add(btnOK);
        
        homeScreen.setVisible(true); // add all other elements before setting visibility
        
********/

