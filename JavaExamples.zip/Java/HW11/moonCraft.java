public class moonCraft
{

   public static void main (String[] args)
   {
   
      Sailor s1 = new Sailor();
      Sailor s2 = new Sailor();
      
      s1.hit(10);
      
      System.out.println(s1.getEnergy());
      System.out.println(s2.getEnergy());
      
     
     
      /**** s1.setEnergy(80);
      s1.setY(350);
      s1.setX(800);
      
      s2.setEnergy(90);
      s2.setY(590);
      s2.setX(680);
      
      
      System.out.println(s1.getEnergy());
      System.out.println(s1.getY());
      System.out.println(s1.getX());
      
      System.out.println(s2.getEnergy());
      System.out.println(s2.getY());
      System.out.println(s2.getX());*/
   
   
   }
}