import java.util.*;

public class BankOperation
{
   public static void main (String[] args)
   {
      BankAccount b1 = new BankAccount("Ashton", 12345);
      Scanner in = new Scanner (System.in);
      int userChoice = 0;
      double deposit = 0.0;
      double withdrawal = 0.0;
      do
      {
         //prompt user to select what they want to do
         System.out.println ("Press 1 to make a deposit");
         System.out.println("Press 2 to make a withdrawal");
         System.out.println("Press 3 to get account information");
         System.out.println("Press 4 to quit");
         userChoice = in.nextInt();
         
         //check for valid choice
         if (userChoice != 1 || userChoice != 2 || userChoice != 3)
         {
            System.out.println("Invalid choice, please try again.");
         }
         
         //deposit
         if (userChoice == 1)
         {
            System.out.println("How much would you like deposit?");
            deposit = in.nextDouble();
            
            b1.deposit(deposit);
            
            System.out.println("Your balance is: " + b1.getBalance());
            
         }
         
         //withdraw
         if (userChoice == 2)
         {
            System.out.println("How much would you like to withdrawal?");
            withdrawal = in.nextDouble();
            b1.withdraw(withdrawal);
            
            System.out.println("Your balance is: " + b1.getBalance());
         
         }
         
         //account info
         if (userChoice == 3)
         {
            System.out.println("Name: " + b1.getName());
            System.out.println("Account Number:" + b1.getAccountNum());
            System.out.println("Account Balance:" + b1.getBalance());
         }
      }while(userChoice != 4);
     
      //end message
      System.out.println("Thank you for your business!");
      
   }// end main


}// end class