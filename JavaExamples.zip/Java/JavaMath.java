/**************************************************
* math symbold add = + minus = - times = * divide = /
* Modulus operator = if you want to know remainder it is represented
by % sign
* if you take a variable like x and make it x++ it will increment( make bigger) it
if you taka a variable like x and make it x-- it will decrement( make smaller) it 
* to increase by one use ++ to decrease by one use -- to times use *=
to divide use /=
*
**************************************************/
public class JavaMath
{

   public static void main (String[] args)
   {
   
   
      int a = 1;
      
      a *= 5;
      
      System.out.println(a);
      
      
      
      
      
      
   
   
   
   
   }






}