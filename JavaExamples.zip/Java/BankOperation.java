public class BankOperation
{
   public static void main (String[] args)
   {
   
      BankAccount b = new BankAccount("Ashton", 12345);
   
   }


}