import java.util.Scanner;

public class MoreMethodFun
{
   public static void main (String[] args)
   {
      
      System.out.println(Math.pow(2,5));
   }
      
}