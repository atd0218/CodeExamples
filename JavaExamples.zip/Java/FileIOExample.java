import java.util.*;
import java.io.*;

public class FileIOExample
{
   public static void main (String[] args)
   {
      Scanner in = new Scanner (System.in);
      File f;
      Scanner fileIn;
      ArrayList<String> words = new ArrayList<String>();
      String fileName = "";
     
      try
      {
         // get file name from user to build file
         System.out.println("Please enter the name of the file you want to print out backwards");
         fileName = in.nextLine();
         
         // build file attatch scanner to it 
         f = new File (fileName);
         fileIn = new Scanner (f);
         
      }
      catch (FileNotFoundException e)
      {
         System.out.println("Sorry, invalid file");
      
      }
      
      
      
   
   
   }



}