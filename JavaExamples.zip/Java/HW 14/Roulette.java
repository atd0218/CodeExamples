import java.util.*;

public class Roulette
{
   int userChoice = 0;
   double result = 0.0;
   int userNum = 0;
   Random r = new Random();
   int num = 0;
   
   
   public double betOnce(Scanner in, double bet)
   {
   
      // statement asking user to bet high or low
      
      System.out.println("Choose 1 for low or 2 for high or 3 for a number.");
      userChoice = in.nextInt();
      
     
      
      // check for valid input
      if (userChoice != 1 && userChoice != 2 && userChoice != 3)
      {
      
         System.out.println("Sorry invalid choice. Please choose 1)low 2)high or 3)a number");
         userChoice = in.nextInt();
      
      }
      //generate random number
      num = r.nextInt(37);
      
      //conditional statements
      if (userChoice == 1 && num <= 18)
      {
         result = bet * 2;
         System.out.println("The number was: " + num + "!");
         System.out.println("you win!");
         
               
      }
      if (userChoice == 1 && num >= 19)
      {
         result = bet - bet;
         System.out.println("The number was: " + num + "!");
         System.out.println("You lose!");
         
         
      
      }
      
       if (userChoice == 2 && num >= 19)
      {
      
         result = bet * 2;
         System.out.println("The number was: " + num + "!");
         System.out.println("you win!");
         
        
      
      }
      if (userChoice == 2 && num <= 18)
      {
          result = bet - bet;
          System.out.println("The number was: " + num + "!");
          System.out.println("You lose!");
         
              
      }
      
      if (userChoice == 3)
      {
         System.out.println("Please choose a number between 1 and 36.");
         userNum = in.nextInt();
         
         
         if (userNum == num)
         {
            result = bet * 34;
         
         }
         else
         {  
            result = bet - bet;
         }
         
         result = result;
         
         System.out.println("the number was: " + num + ".");
      }
      
    
         
       return result;

    }// end method

  }// end class