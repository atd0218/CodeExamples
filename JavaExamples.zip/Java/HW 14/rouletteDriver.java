import java.util.*;

public class rouletteDriver
{

   public static void main (String[] args)
   {
      Scanner in = new Scanner (System.in);
      Random r = new Random();
      roulette g = new roulette();
      int num = r.nextInt(37);
     
      
      
   }

}