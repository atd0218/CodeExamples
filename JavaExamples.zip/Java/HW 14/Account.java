import java.util.*;

public class Account
{
   public static void main (String[] args)
   {
   
        Calculators c = new Calculators();
        
        Scanner in = new Scanner (System.in);
        
        double balance = 0.0; // account balance
        
        double compoundedBalance = 0.0;
        double earned = 0.0;
        
        System.out.println("What is the balance in the account?");
        balance = in.nextInt();
        
             
        compoundedBalance = c.compoundInterest(balance, in);
        
        earned = compoundedBalance - balance;
        
        System.out.printf("You earned %.2f in Interest.\n", earned);
   
   }

}