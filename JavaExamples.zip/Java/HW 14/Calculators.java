import java.util.*;

public class Calculators
{

   public double compoundInterest (double balance, Scanner in)
   {
      
      
      double interestRate = 0.0; // rate represented as a decimal
      int term = 0; // term of the interest in years
      
      double updatedBalance = 0.0; // calculated balance
      
      
      // get more info from user
      
      System.out.println("What is the interest rate?");
      interestRate = in.nextDouble();
      
      System.out.println("What is the term (in years)?");
      term = in.nextInt();
      
      // compound interest for the number of terms
      updatedBalance = balance;
      
      for (int i = 1; i <= term; i++)
      {
         updatedBalance = updatedBalance * (1 + interestRate);
      }
            
      return updatedBalance;
   }


}