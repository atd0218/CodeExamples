public class VariableTypesFun
{

   public static void main (String[] args)
   {
   
      
      //int - 32 bit - +/- ~2 billion
      //long - 64 bit - REALLY big WHOLE numbers
      
      //float - 32 bit - same as double but smaller
      //double - 64 bit- REALLY big OR REALLY small FLOATING point numbers
      
      // byte- 8 bit - use for a number -128 to 127 
      
      // boolean - 8 bit - True or False values
      // char - 8 bit- ASCII Character
      // String - only capital!! - set of char to hold sentences
      
      String sentence = "This is a sentence";
   
   
   }




}