import java.util.Scanner;

public class ORNotLogicalFun
{

   public static void main (String[] args)
   {
   
      // if there is and an or in if statement then and will come first
      // && = AND
      // || = OR
      // ! = NOT
      
      Scanner in = new Scanner (System.in);
      String name = "";
      int age = 0;
      
      // ask user to enter name & age
      
      System.out.println("Please enter your name?");
      name = in.nextLine();
      
      System.out.println("How old are you?");
      age = in.nextInt();
      
      //Decide whether this person is dateable
      if (age < 40 || !name.equals("Brad Pitt"))
      {
         System.out.println("I will date you!");
      
      }
      else
      {
         System.out.println("Sorry you are out of luck!");
      
      }
      
     
     
    
   
   
   
   }



}