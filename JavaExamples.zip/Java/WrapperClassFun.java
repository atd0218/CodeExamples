import java.util.Scanner;

public class WrapperClassFun
{

   public static void main (String[] args)
   {
      
      Scanner in = new Scanner (System.in);
      
      String input = "";
      int adultAge = 0;
      String output = "";
      
      System.out.println("Please enter the year you were born");
      input = in.nextLine();
      
      adultAge = Integer.parseInt(input) + 18;
      // Integer.parseInt = wrapper class
      // the pre built classes are called A.P.I 
      
      output = Integer.toString(adultAge);
      
      
      System.out.println("you will be an adult in " + output);
      
      
   
   }


}