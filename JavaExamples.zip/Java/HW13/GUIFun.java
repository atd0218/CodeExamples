import javax.swing.*;
import java.awt.*;

public class GUIFun // GUI = graphical user interface
{
   public static void main (String[] args)
   {
        Home h = new Home();
            
              
        
   }//end main
   

}//end class 