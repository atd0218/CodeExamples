import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class Game
{
   private JFrame screen2;
   private JTextField input;
   private JLabel instructions;
   private int num = 1;
   private String message = "";
   
   Random r = new Random();
   String[] solution = new String[5];
   String[] colors = {"red", "green", "blue", "yellow", "brown", "purple", "white", "black", "maroon", "turquoise", "fuchia", "salmon"};
   String result = "";
   
       
   //constructor
   public Game()
   {
      Pane();
      CreateContents();
      
      screen2.setVisible(true);   
          
   }
   
   // build Pane
   private void Pane()
   {
      for (int i = 0; i < solution.length; i++)
      {
         solution[i] = colors[r.nextInt(12)];
         result = colors.toString();
      }
   
      
      JOptionPane.showMessageDialog(null, "Want to test your memory?\nMemorize these colors in order: " + solution[0] + " " +
         solution[1] +  " " + solution[2]+ " " + solution[3]+ " "  + solution[4]);
     
      
   }
   
   private void CreateContents ()
   {
        // add frame
        
      screen2 = new JFrame();
         
      screen2.setSize(400,200);
      screen2.setTitle("Memory Game");
      screen2.setDefaultCloseOperation(screen2.EXIT_ON_CLOSE);
      screen2.setLayout(new FlowLayout());
        
        //build contents
      instructions = new JLabel("what was color # " + num);
      input = new JTextField(20);
        
        //actions
      input.addActionListener(new Listener());
        
        //add contents
      screen2.add(instructions);
      screen2.add(input);
        
   
   
   }
   
   private class Listener implements ActionListener
   {
      public void actionPerformed (ActionEvent e)
      {
         String guess = "";
         guess = input.getText();
         
         
         
         if (solution[num-1].equalsIgnoreCase(guess))
         {
            instructions.setText("Correct");
            num++;
            if(num <= 5)
            {
               instructions.setText("what was color #" + num);
               input.setText("");
            }
            if(num > 5)
            {
               instructions.setText("You Won you have great memory!");
               input.setVisible(false);
            }   
         }
         else
         {
            instructions.setText("Incorrect");
            input.setVisible(false);
         }
              
      }
      
     
   
   }
   
   public static void main (String[] args)
   {
      Game g = new Game();
         
      
   }


}



/************* 

// private JFrame Screen;
 //private JLabel lblName;
  //private JLabel lblName2;
  //private JLabel colors;
  //private JTextField txtName;
  //private JButton btnOK;


 other ways i tried to do this i want to keep for reference
  //getting frame 
      Screen = new JFrame();
      Screen.setSize(400,200);
      Screen.setTitle("Memory Game");
      Screen.setDefaultCloseOperation(Screen.EXIT_ON_CLOSE);
      Screen.setLayout(new FlowLayout());  
      
      
      // build contents to frame
      
      lblName = new JLabel("How good is your memory?");
      lblName2 = new JLabel("Try to memorize the color sequence");
      colors = new JLabel("Red White Yellow Green Blue");
      txtName = new JTextField(20);
      btnOK = new JButton("OK");
      
      
      //set action for button
      btnOK.addActionListener(new Listener());
      


      
      //add contents to frame
      Screen.add(lblName);
      Screen.add(lblName2);
      Screen.add(colors);
      Screen.add(btnOK);
   ******/
         
