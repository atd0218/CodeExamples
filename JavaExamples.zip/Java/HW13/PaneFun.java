import javax.swing.JOptionPane;

public class PaneFun
{
   public static void main (String[] args)
   {
   
      String favTeam = "";
      int favNum = 0;
      int selection = 0;
      
      //show message box
      JOptionPane.showMessageDialog(null, "Hi\nHow are you?");
      
      
      //imput dialog box
      
      favTeam = JOptionPane.showInputDialog(null, "What is your favorite team?");
      
      JOptionPane.showMessageDialog(null, favTeam + " is a good team");
      
      // if you want to make this compatible with integer
      favNum = Integer.parseInt(JOptionPane.showInputDialog(null, "Tell me your favorite number?"));
      
      JOptionPane.showMessageDialog(null, favNum + " is cool.");
      
      // show confirm box
      
     selection = JOptionPane.showConfirmDialog(null, "Best Videos Ever?");
      
     if (selection == JOptionPane.NO_OPTION)
     {
         JOptionPane.showMessageDialog(null, "Boo");
     
     } 
     if (selection == JOptionPane.YES_OPTION)
     {
         JOptionPane.showMessageDialog(null, "You are my best friend");
      
     }
   }

}