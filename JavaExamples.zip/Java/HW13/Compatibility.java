import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

public class Compatibility
{
   private JFrame mainWindow;
   private JLabel lblName1;
   private JLabel lblName2;
   private JTextField txtName1;
   private JTextField txtName2;
   private JButton btnCheck;
   private JLabel lblResult;
   


   public Compatibility()
   {
      createContents();
      
      mainWindow.setVisible(true);
   
   }
   //constructor
   private void createContents()
   {
      //set frame and options
     
      mainWindow = new JFrame();
         
      mainWindow.setSize(600,200);
      mainWindow.setTitle("Check your compatibility!");
      mainWindow.setDefaultCloseOperation(mainWindow.EXIT_ON_CLOSE);
      mainWindow.setLayout(new FlowLayout());
      
      //build contents
      lblName1 = new JLabel("Enter your name:");
      lblName2 = new JLabel("Enter the name of the lucky girl:");
      txtName1 = new JTextField(20);
      txtName2 = new JTextField(20);
      btnCheck = new JButton("Check Compatibility");
      lblResult = new JLabel("");
      
      //add contents
      mainWindow.add(lblName1);
      mainWindow.add(txtName1);
      mainWindow.add(lblName2);
      mainWindow.add(txtName2);
      mainWindow.add(btnCheck);
      mainWindow.add(lblResult);
      
      //add action listener
      
      btnCheck.addActionListener(new checkListener());
      
   
   }//end of create contents
   
   private class checkListener implements ActionListener
   {
   
      public void actionPerformed(ActionEvent e)
      {
         Random r = new Random();
         int fate = 0;
         String name1 = txtName1.getText();
         String name2 = txtName2.getText();
         
         if (name1.equals(""))
         {
            lblResult.setText("missing name1");
         }
         else if (name2.equals(""))
         {
            lblResult.setText("missing name2");
         }
         else
         {
   
            
            //determine fate 
            fate = r.nextInt(2);
            
            if (fate == 0)
            {
               lblResult.setText("Love is in the air!");
               
            
            }
            if (fate == 1)
            {
               lblResult.setText("No love is in the cards for you my friend!");
            
            }
         }
      }
   
   }

}//end class