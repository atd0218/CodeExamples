/****************************************************
* assiging variable= left= where we assing right= what we assign
*char letter = ' ';
* String sentence = ""; examples of initializing
* when casting you take your information and turn it into something else
* when casting integers can fit into doubles, but doubles cant fit into 
integers
*
****************************************************/

public class VariableAssignmentFun
{

   public static void main (String[] args)
   {
   
   
      double buildingheight = 0; //Initialization//
      
      buildingheight = (double)150; // assigning variable//  
      
      System.out.println(buildingheight);
// when you initialize dont use a legal value so you know you have to fix it//
      
         
   
   
   }



}