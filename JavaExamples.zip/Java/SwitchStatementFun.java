import java.util.*;

public class SwitchStatementFun
{

   public static void main (String[] args)
   {
   
      Scanner in = new Scanner (System.in);
      int age = 0;
      
      //Get the age from the user
      System.out.println("Please enter your age");
      age = in.nextInt();
      
      //Print comment based on age
      switch (age)
      {
      
         case 16:
            System.out.println("Congratulations! you can drive");
            break;
            
         case 21:
            System.out.println("Congratulations! you can drink!");
            break;
            
         case 25:
            System.out.println("Congratulations! you can rent a car"); 
            break; 
            
         default:
            System.out.println("Wow... Boring age.");
      
      }
   
   
   
   }



}