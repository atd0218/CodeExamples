/**********************************************
* ReadabilityFun.Java
* Ashton Daniels
*
* This class helps us learn about readability
***********************************************/

public class ReadabilityFun
{
   public static void main (String[] args)
   {
      //Print some stuff 
      System.out.println("this is some text");
      System.out.println("this is some more text");
      
   }  //end main


} //end class ReadabiltyFun