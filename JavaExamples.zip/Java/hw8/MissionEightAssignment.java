import java.util.*;


public class MissionEightAssignment
{

   public static void main (String[] args)
   {
      
      Scanner in = new Scanner (System.in);
        
      double userInput = 0;
      double height = 0;
      double weight = 0;
      double constant = 704;
      boolean error = false;
      
      
      
      
      System.out.println("Wanna find out your Body Mass Index?");
      
      // get user input for weight
      
      //System.out.println("Please enter your weight?");
      //weight = in.nextInt();
      
      // get user input for height
      
      //System.out.println("Please enter your height in inches?");
      //height = in.nextInt();
      
      System.out.println("Please enter your weight!");
      do
      {
         try
         {
          
            weight = in.nextDouble();
            error = false;
            if(weight < 0)
            {
               System.out.println("Invalid Input! please enter a positive number.");
               error = true;
            
            }
           
            
         }
         catch (InputMismatchException e)
         {
            //Flush the buffer
            in.nextLine();
             error = true;
             System.out.println("Invalid input! Enter your weight in numbers.");
             
         }
      }while(error);
      
      
      System.out.println("Please enter your height in inches?");
      
      do
      {
         try
         {
            height = in.nextDouble();
            error = false;
            if(height < 0)
            {
               System.out.println("Invalid Input! Please enter a positive number.");
               error = true;
            }
   
         }
         catch (InputMismatchException e)
         {
            
            //Flush the buffer
            in.nextLine();
            
            System.out.println("Invalid input! Enter your height in inches.");
            error = true;
            
            
         }
      }while(error);
      
      //print results and calculate BMI
      
      System.out.println("Your weight is" + ": " + weight);
      System.out.println("Your height is" + ": " + height);
      System.out.println("Your Body Mass Index is" + ": " + (constant * weight)/ (height * height));
      

      
     
   
   
   
   
   }// end main 




}// end class