/***********************************************
* if we know how many times we want the program to execute we use a for loop
it is called a definite loop 
*
*
*
*
*
***********************************************/

public class ForFun
{

   public static void main (String[] args)
   {
     
      
     for (int i = 1; i <= 15; i++)
     {
        
         System.out.println(i +  " squared is "  + (i*i));
        
     
     
     }   
   
   
   }


}