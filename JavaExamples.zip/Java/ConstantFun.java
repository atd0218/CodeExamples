/********************************************************
* if you put final in front of something it means that the variable can no
longer be changed
* named constant is when you want something to be the same throughout
the whole program
*when using a named constant the right type of convention would be to name it 
IN ALL CAPS
*
*
*
*
*
*
********************************************************/
public class ConstantFun
{

   public static void main (String[] args)
   {
   
     final double INTERESTRATE = 5.0; // Named Constant//
     
   System.out.println(INTERESTRATE);
      
   
   
   }



}