import java.util.Scanner; 
import java.util.Random;

public class CoinFlipGame
{

   public static void main (String[] args)
   {
      Scanner in = new Scanner (System.in);
      Random r = new Random();
      
      int userPick = 0; // 1 for heads 2 for tails
      int flipResult = 0; // 1 for heads 2 for tails
      int numberOfFlips = 0; 
      int numberOfWins = 0;
      String playAgain = ""; // Y or N
      
      // play the game while the user continues to press Y
      
      do
      {
         //Getting user selection
         System.out.println("Enter 1 for Heads, or 2 for Tails");
         userPick = in.nextInt();
         
         //Check for valid input
            while(userPick != 1 && userPick != 2)
            {
               
               System.out.println("Invalid input!");
               System.out.println("Enter 1 for Heads, or 2 for Tails");
               userPick = in.nextInt();
            
            }
         
           //Simulate the coin flip and increase count of games
           flipResult = r.nextInt(2) + 1; 
           numberOfFlips++;
           
           if (flipResult == 1)
           {
               System.out.println("It was heads!");
            
           }
           if (flipResult == 2)
           {
               System.out.println("it was tails!");
           
           }
           
           //Check and print results
           if (userPick == flipResult)
           {
           
               System.out.println("You Win!");
               numberOfWins++;
           }
           else 
           {
           
               System.out.println("You Lose!");
           }
           
           //Flush the buffer
               in.nextLine();
           
            
      
           //See if user wants to continue
         System.out.println("Play Again? Y or N ");
         playAgain = in.nextLine();
         
            //Check for valid input
            while (!playAgain.equalsIgnoreCase("Y") && !playAgain.equalsIgnoreCase("N"))
            {
         
               System.out.println("Invalid input. Try again?"); 
               System.out.println("Play again? Y or N?");
               playAgain = in.nextLine();
            }
         
      }  while(playAgain.equalsIgnoreCase("Y")); 
      
      // Print game results
      
      System.out.println("YOU Won " + numberOfWins + " Out of " + numberOfFlips + " Games ");
      System.out.println("That's " + 
         (((double) numberOfWins / numberOfFlips) * 100) + "%!");
   
   
   
   
   }



}