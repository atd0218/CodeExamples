/**********************************************8
* Boolean is something that holds a true or false
* when doing boolean if statments to use a not you would put ! before your named
variable
*
*
*
***********************************************/


public class BooleanComparisonFun
{

   public static void main (String[] args)
   {
   
      boolean error = false;
      
      if (!error)
      {
         System.out.println("No errors");
      
      }
      
      
   
   
   
   }



}