public class MissionThree
{

   public static void main (String[] args)
   {
   
      
   
   
   
   
   }




}