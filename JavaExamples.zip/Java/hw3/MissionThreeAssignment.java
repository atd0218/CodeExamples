import java.util.Random;
import java.util.Scanner;


public class MissionThreeAssignment
{

   public static void main (String[] args)
   {
   
      Scanner in = new Scanner (System.in);
      Random a = new Random();
      
      int userPick = 0;
      int numberOfTries = 0;
      String wrongGuess = "";
      
      do
      {
      
      
      
      
      
      
      
      
      
      } while(userPick != #);
      
         System.out.println("It took you" + numberOfTries);
      
      
      

   
   
   
   
   }

}