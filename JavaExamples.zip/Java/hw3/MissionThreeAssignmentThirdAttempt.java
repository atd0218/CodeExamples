import java.util.Random;
import java.util.Scanner;


public class MissionThreeAssignmentThirdAttempt
{

   public static void main (String[] args)
   {
   
      Scanner in = new Scanner (System.in);
      Random a = new Random();
      
      int number = 0; // random number generated
      int userPick = 0;// users number 1 to 100
      int numberOfTries = 0;// indicate number of times played
      String wrongGuess = "";
      
      //Greet the user
      System.out.println("Welcome!");
      
      //generate a number
      number = in.nextInt(100) + 1;
      
      // Ask user to pick a number
      System.out.println("Please choose a number 1 to 100!");
      //Flush the buffer
      in.nextLine();
      number = a.nextInt(100) + 1;

      for(int i = 1; i , i <= numberOfTries; i++)
      {
            numberOfTries = i;
      }

      
      do
      {
        

         while(userPick < 1 || userPick > 100)
         
            System.out.println("Invalid Input... Please try again.");


         
            
         
      
      
      
      
      
      
      
      
      } while(userPick != number);
      
         System.out.println("It took you" + numberOfTries);
      
      
      

   
   
   
   
   }

}