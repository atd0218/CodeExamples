<?php

session_start();
require 'dbcon.php';


/*//db connection constants

$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'W01232820';
$DATABASE_PASS = 'Ashtoncs!';
$DATABASE_NAME = 'W01232820';

// Try and connect using the info above.
$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);

if ( mysqli_connect_errno() ) {

  // If there is an error with the connection, stop the script and display the error.
die ('Failed to connect to MySQL: ' . mysqli_connect_error());
}*/

// first check if email and code exists
if (isset($_GET['email'], $_GET['code']))
{
	//create a statement to go into our data base and find email and activation code
	if($stmt = $con->prepare('SELECT * FROM accounts WHERE email = ? AND activation_code = ?'))	
	{
		//bind email and activation code from statement and put in variables
		$stmt->bind_param('ss', $_GET['email'], $_GET['code']);
		//execute statement
		$stmt->execute();
		//store result of statement
		$stmt->store_result();
		
		//if there is 1 row of data in results of statement
		if($stmt->num_rows > 0)
		{
			// prepare statement to begin updating activation code
			if($stmt = $con->prepare('UPDATE accounts SET activation_code = ? WHERE email = ?
			AND activation_code = ?'))
			{
				//create new variable to activate code
				$newcode = 'activated';
				//binds newcode with email and original activation code
				$stmt->bind_param('sss', $newcode, $_GET['email'], $_GET['code']);
				//executes statement
				$stmt->execute();
				
				header('Location: index.php?message=account is now activated');
				<?php <p class="displayerr">Your account is now activated you can now login</p>?>;
				//echo 'Your account is now activated you can now login at!<br><a href="index.html">Login</a>';
			}
		}
	}
}
else
{
	header('Location: index.php?message=Account already exists');
	<?php <p class="displayerr">Account already exists</p>?>;
}




?>