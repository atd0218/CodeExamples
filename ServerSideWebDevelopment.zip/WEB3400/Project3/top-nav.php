<head>
<body>
<nav class="navbar is-light" role="navigation" aria-label="main navigation">
        <div class="navbar-brand">
            <a class="navbar-item" href="home.php">
                <h1 class="title">My Website</h1>
            </a>

            <a role="button" class="navbar-burger burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
                <span aria-hidden="true"></span>
                <span aria-hidden="true"></span>
                <span aria-hidden="true"></span>
            </a>
        </div>

        <div id="navbarBasicExample" class="navbar-menu">

            <div class="navbar-start">
                <!--       <a class="navbar-item">
        Home
      </a> -->
            </div>

            <div class="navbar-end">
                <div class="navbar-item">
                    <div class="buttons">
                        <a href="profile.php" class="button">
                            <span class="icon"><i class="fas fa-user-circle"></i></span><span>Profile</span>
                        </a>
                        <a href="logout.php" class="button">
                            <span class="icon"><i class="fas fa-sign-out-alt"></i></span><span>Logout</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

</body>
</head>