<?php
include 'functions.php';
$pdo = pdo_connect_mysql();
?>

<?=template_header('Reviews System');?>

<?=template_nav();?>

<!-- document main content goes here -->
<section class="section">
  <div class="container">
    <h1 class="title">Reviews</h1>
    <h2 class="subtitle">Check out the below reviews for our website.</h2>
    <!--   reviews go here   -->
  </div>
</section>

<?=template_footer();?>