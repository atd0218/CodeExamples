<?php

//database conn
$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'W00405514';
$DATABASE_PASS = 'Aaroncs!';
$DATABASE_NAME = 'W00405514';

// Try and connect using the info above.
$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);

if ( mysqli_connect_errno() ) {

  // If there is an error with the connection, stop the script and display the error.
$_SESSION['connfail'] = ('Failed to connect to MySQL: ' . mysqli_connect_error());
header('Location: index.php?message=mysql error');
//die ('Failed to connect to MySQL: ' . mysqli_connect_error());
}

?>