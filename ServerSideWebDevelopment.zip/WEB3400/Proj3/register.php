<?php
session_start();
require 'dbcon.php';

/* //database conn
$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'W00405514';
$DATABASE_PASS = 'Aaroncs!';
$DATABASE_NAME = 'W00405514';

// Try and connect using the info above.
$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);

if ( mysqli_connect_errno() ) {

  // If there is an error with the connection, stop the script and display the error.
die ('Failed to connect to MySQL: ' . mysqli_connect_error());
} */

if (!isset($_POST['username'], $_POST['password'], $_POST['email'])) 
    {  
      $_SESSION['RegUF1'] = 'Please complete the registration form!';
      header('Location: register1.php?message=Invalid Userform');
      //die('Please complete the registration form!');
    }
elseif (empty($_POST['username']) || empty($_POST['password']) || empty($_POST['email'])) {
  $_SESSION['RegUF2'] = 'Please complete the registration form!';
  header('Location: register1.php?message=Invalid Userform');
 // die('Please complete the registration form!');
}
elseif (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
  $_SESSION['RegUF3'] = 'Email is not valid';
  header('Location: register1.php?message=Invalid Userform, Email');
  //die ("Email is not valid");
}
//match username to alphanumeric
elseif(preg_match('/[A-Za-z0-9]+/', $_POST['username']) == 0){
  $_SESSION['RegUF4'] = 'Username is not valid';
  header('Location: register1.php?message=Invalid Userform, Username');
  //die("Username is not valid");
}
elseif(strlen($_POST['password']) > 20 || strlen($_POST['password']) < 8 ){
  $_SESSION['RegUF5'] = 'Password must be between 8 and 20 characters long!';
  header('Location: register1.php?message=Invalid Userform, Password');
  //die("Password must be between 8 and 20 characters long!"); 
}

if ($sql = $con->prepare('SELECT id, password FROM accounts WHERE username = ?')) {
$sql->bind_param('s', $_POST['username']);
$sql->execute();
// Store the result so we can check if the account exists in the database.
$sql->store_result();

if ($sql->num_rows > 0) {
//username already exists

$_SESSION['badname'] = 'Username already exists';  
header('Location: register1.php?message=Invalid Username, Exists');
//echo "Username already exists";

}else{
 
if($stmt = $con->prepare('INSERT INTO accounts (username, password, email, activation_code) VALUES (?, ?, ?, ?)')) {
   
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
$uniqid = uniqid(); 
$stmt->bind_param('ssss', $_POST['username'], $password, $_POST['email'], $uniqid);
$stmt->execute();
//echo"You have successfully regestered, you can now log in!";
//header('Location: index.html?registered=true');


$from = 'jaaronfillmore@mail.weber.edu';
$subject = 'Account Activation Required';
$headers = 'From: ' . $from . "\r\n" . 'Reply-To: ' . $from . "\r\n" . 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'MIME-Version: 1.0' . "\r\n" . 'Content-Type: text/html; charset=UTF-8' . "\r\n";
$activate_link = 'http://icarus.cs.weber.edu/~jf05514/web3400/project3/activate.php?email=' . $_POST['email'] . '&code=' . $uniqid;
$message = '<p>Please click the following link to activate your account: <a href="' . $activate_link . '">' . $activate_link . '</a></p>';

mail($_POST['email'], $subject, $message, $headers);  

$_SESSION['chkEmail'] = 'Please check your email to activate your account!';  
header('Location: index.php?message=Check Email');
//echo "Please check your email to activate your account!";
  
}else{
  
  $_SESSION['badsql1'] = 'Could not prepare statement!'; 
  header('Location: register1.php?message=Invalid sql call 1');
  //echo"Could not prepare statement!";
}
//insert a new record  
}
$sql->close();
} else {
  $_SESSION['badsql2'] = 'Could not prepare statement!'; 
  header('Location: register1.php?message=Invalid sql call 2');
  //echo "Could not prepare statement!"; 
}
  
$con->close(); 
?>