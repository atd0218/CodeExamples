<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Welcome!</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.8.0/css/bulma.min.css">
    <script defer src="https://use.fontawesome.com/releases/v5.3.1/js/all.js"></script>
    <script src="js/main.js"></script>
</head>

<body>
<?php 

include 'top-nav.php';
                      
if (isset ($_SESSION['connfail']) && ! empty($_SESSION['connfail']))
    {echo $_SESSION['connfail'];}
  
if (isset ($_SESSION['chkEmail']) && ! empty($_SESSION['chkEmail']))
    {echo $_SESSION['chkEmail'];} 
  
?> 
  
  <!--  
    <nav class="navbar is-light" role="navigation" aria-label="main navigation">
        <div class="navbar-brand">
            <a class="navbar-item" href="index.html">
                <h1 class="title">My Website</h1>
            </a>

            <a role="button" class="navbar-burger burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
                <span aria-hidden="true"></span>
                <span aria-hidden="true"></span>
                <span aria-hidden="true"></span>
            </a>
        </div>

        <div id="navbarBasicExample" class="navbar-menu">

            <div class="navbar-start">

            </div>

            <div class="navbar-end">
                <div class="navbar-item">
                    <div class="buttons">
                        
                        <a href="profile.php" class="button">
                            <span class="icon"><i class="fas fa-user-circle"></i></span><span>Profile</span>
                        </a>
                        <a href="logout.php" class="button">
                            <span class="icon"><i class="fas fa-sign-out-alt"></i></span><span>Logout</span>
                        </a>

                    </div>
                </div>
            </div>
        </div>
    </nav>-->
    <section class="section">
        <div class="container">
            <h1 class="title">
                Login
            </h1>
            <form action="authenticate.php" method="post">
                <div class="field">
                    <div class="control has-icons-left has-icons-right">
                        <input class="input" type="text" placeholder="Username" name="username">
                        <span class="icon is-small is-left">
                            <i class="fas fa-user"></i>
                        </span>
                        <span class="icon is-small is-right">
                            <i class="fas fa-check"></i>        
                        </span> 

                    </div>
                      <?php 
                      if (isset ($_SESSION[ 'UN']) && ! empty( $_SESSION[ 'UN']))
                      {
                      echo $_SESSION[ 'UN'];
                      }
                      ?>                       
                </div>
                <div class="field">
                    <p class="control has-icons-left">
                        <input class="input" type="password" placeholder="Password" name="password">
                        <span class="icon is-small is-left">
                            <i class="fas fa-lock"></i>
                        </span>
                    </p>
                      
                      <?php 
                      if (isset ($_SESSION[ 'PW']) && ! empty( $_SESSION[ 'PW']))
                      {
                      echo $_SESSION[ 'PW'];
                      }
                      ?>   
              </div>

                <div class="field">
                    <p class="control">
                        <button class="button is-success">
                            Login
                        </button>
                    </p>
                </div>
            </form>
        </div>
    </section>
    <section class="section">
        <div class="container">
            <h2 class="subtitle">
                Don't have an account?
            </h2>
            <a class="button is-small is-link" href="register1.php">Register</a>
        </div>
    </section>
  
 <?php session_destroy(); ?>
</body></html>


