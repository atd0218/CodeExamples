<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: index.php');
	exit();
} else {
if (isset($_SESSION['loggedin'])) {

    require 'dbcon.php';

    $sql = $con->prepare('SELECT activation_code FROM accounts WHERE id = ?');

    // In this case we can use the account ID to get the account info.
    $sql->bind_param('i', $_SESSION['id']);
    $sql->execute();
    $sql->bind_result($activation_code);
    $sql->fetch();
    $sql->close();

    $_SESSION[ 'TestActive'] = $activation_code;
    }
}
?>