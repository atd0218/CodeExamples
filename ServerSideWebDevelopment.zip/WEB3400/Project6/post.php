<?php
include 'functions.php';

// Connect to MySQL
$pdo = pdo_connect_mysql();

// To Do:
// If the 'id' isset then prepare, execut and fetch the 
// blog post from the database and stores the result in $post 

?>

<?=template_header('Blog Post');?>

<?=template_nav();?>

<!-- document main content goes here -->
<section class="section">
    <div class="container">
        <h1 class="title">
            <?=$post['title']?>
        </h1>
        <p class="subtitle">
            <?=$post['author_name']?> -
            <?=$post['created']?>
        </p>
        <p>
            <?=$post['content']?>
        </p>
        <!-- To Do: Add the page reviews div and javascript here for this page-->
    </div>
</section>

<?=template_footer();?>
