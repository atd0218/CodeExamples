<?php
include 'functions.php';

// Connect to MySQL
$pdo = pdo_connect_mysql();

// MySQL query that selects all the polls and poll answers
$stmt = $pdo->query('SELECT `id`, `author_name`, `title`, SUBSTRING(`content`,1, 100) AS content, `published`, `created` FROM `blog_post`');
$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<?=template_header('Blog Posts');?>

<?=template_nav();?>

<!-- document main content goes here -->
<section class="section">
    <div class="container">
        <h1 class="title">Blog Posts</h1>
        <p class="subtitle">Welcome, you can view, edit or delete blog posts below.</p>
        <a href="create.php" class="button is-primary is-small">
            <span class="icon"><i class="fas fa-plus"></i></span>
            <span>Create Post</span>
        </a>
    </div>
    <p>&nbsp;</p>
    <div class="container">
        <table class="table is-bordered">
            <thead>
                <tr>
                    <td>#</td>
                    <td>Author Name</td>
                    <td>Title</td>
                    <td>Content</td>
                    <td>Published</td>
                    <td>Created</td>
                    <td>Action</td>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($posts as $post): ?>
                <tr>
                    <td>
                        <?=$post['id']?>
                    </td>
                    <td>
                        <?=$post['author_name']?>
                    </td>
                    <td>
                        <?=$post['title']?>
                    </td>
                    <td>
                        <?=$post['content']?>
                    </td>
                    <td>
                        <?=$post['published']?>
                    </td>
                    <td>
                        <?=$post['created']?>
                    </td>
                    <td>
                        <a href="update.php?id=<?=$post['id']?>" class="button is-link is-small" title="Edit Post">
                            <span class="icon"><i class="fas fa-edit"></i></span>
                        </a>
                        <a href="delete.php?id=<?=$post['id']?>" class="button is-danger is-small" title="Delete Post">
                            <span class="icon"><i class="fas fa-trash"></i></span>
                        </a>
                    </td>
                </tr>
                <?php endforeach;?>
            </tbody>
        </table>
    </div>
</section>

<?=template_footer();?>
