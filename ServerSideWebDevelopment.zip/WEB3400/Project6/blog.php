<?php
include 'functions.php';

// Connect to MySQL
$pdo = pdo_connect_mysql();

// MySQL query that selects all the blog posts
$stmt = $pdo->query('SELECT `id`, `author_name`, `title`, SUBSTRING(`content`,1, 100) AS content, `published`, DATE_FORMAT(created, "%M %d %Y") AS `created` FROM `blog_post` WHERE published = 1');
$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<?=template_header('Blog Posts');?>

<?=template_nav();?>

<!-- document main content goes here -->
<section class="section">
    <div class="container">
        <h1 class="title">Blog Posts</h1>
        <p class="subtitle">Welcome, you can view our blog posts below.</p>
    </div>
    <p>&nbsp;</p>
    <div class="container">
        <?php foreach ($posts as $post): ?>
        <section class="section">
            <div class="columns">
                <div class="column is-8 is-offset-2">
                    <div class="content is-medium">
                        <h2 class="subtitle is-4">
                            <?=$post['created']?>
                        </h2>
                        <h1 class="title">
                            <?=$post['title']?>
                        </h1>
                        <p>
                            <?=$post['content']?>
                        </p>
                        <p><a href="post.php?id=<?=$post['id']?>" class="button">
                                <span class="icon"><i class="fas fa-glasses"></i></span>
                                <span>Read more...</span>
                            </a></p>
                    </div>
                </div>
            </div>
        </section>
        <hr>
        <?php endforeach;?>

    </div>
</section>

<?=template_footer();?>
