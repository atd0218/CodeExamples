<?php

require 'dbcon.php';
/*//database connection

 

$DATABASE_HOST = 'localhost';

 

$DATABASE_USER = 'W01232820';

 

$DATABASE_PASS = 'Ashtoncs!';

 

$DATABASE_NAME = 'W01232820';

 

// Try and connect using the info above.

$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);

 

if ( mysqli_connect_errno() ) {

 

  // If there is an error with the connection, stop the script and display the error.

die ('Failed to connect to MySQL: ' . mysqli_connect_error());

}*/

 

 

 

// Now we check if the data from the login form was submitted, isset() will check if the data exists.

if ( !isset($_POST['username'], $_POST['password'], $_POST['email']))

 {
		// could not get the data that should be sent
     die("PLease Complete Registration Form");

 }   

 
//make sure registration values are not empty
if (empty($_POST['username']) || empty($_POST['password']) || empty($_POST['email'])){
	// one or more values are empty
    die("PLease Complete Registration Form");

 

}

// looks at email string make sure there is @ and .com 
// filter_var used to validate or sanitize(remove) specific fields
if(!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL))
{
	// if email is not correct quit and display message
	die('Email is not valid');
}

// preg_match can be used to only allow certain characters
// it looks at each char in string and compares to parameters we have set
if(preg_match('/[A-Za-z0-9]+/', $_POST['username']) == 0)
{
	// if user is not A-Z, a-z, 0-9 then quit and display message
	die('Username is not valid');
}

// if string length of password is greater than 20 or less than 8 characters
if(strlen($_POST['password']) > 20 || strlen($_POST['password']) < 8)
{
	//we stop the program and display a message
	die('Password must be between 8 and 20 characters!');
}



 

// Prepare our SQL, preparing the SQL statement will prevent SQL injection.

 

if ($sql = $con->prepare('SELECT id, password FROM accounts WHERE username = ?')) {

 

    // Bind parameters (s = string, i = int, b = blob, etc), in our case the username is a string so we use "s"

   

    $sql->bind_param('s', $_POST['username']);

   

    $sql->execute();

   

    // Store the result so we can check if the account exists in the database.

   

    $sql->store_result();

 

    if ($sql->num_rows > 0) {

 

        //Username Already Exists

        echo "Username Already Exists";

    } else {

        //insert new record

    if ($stmt = $con->prepare('INSERT INTO accounts (username, password, email, activation_code) VALUES (?,?,?,?)' )){

 

        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
		//encrypting password 
		
			 $uniqid = uniqid();
             $stmt->bind_param('ssss', $_POST['username'], $password, $_POST ['email'], $uniqid);

             $stmt->execute();// inserts record into database

             //echo 'You have successfully registered, you can now login!';
			 
			 //content for activation email 
			 $from = 'ashtondaniels@mail.weber.edu';
			 $subject = 'Account Activation Required';
			 
			 
			 // properly formed headers help to prevent spam
			 //Content-Type: text/html; charset=UTF-8 this allows us to switch from plain text
			 // to html
			 $headers = 'From: ' . $from . "\r\n" . 'Reply-To: ' . $from . "\r\n" .
			 'X-Mailer: PHP/' . phpversion() . "\r\n" . 'MIME-Version: 1.0' . "\r\n" .
			 'Content-Type: text/html; charset=UTF-8' . "\r\n";
			 
			 
			 // sets up activation link to validate email
			 $activate_link = 'http://icarus.cs.weber.edu/~ad32820/WEB3400/Project3/activate.php?email=' .
			 $_POST['email'] . '&code=' . $uniqid;
			 
			 
			 // message displayed to user prompting them to click link
			 $message = '<p> Please click the following link to activate your account: 
			 <a href="' . $activate_link . '">' . $activate_link . '</a></p>';
			 
			 
			 //send the activation email
			 mail($_POST['email'], $subject, $message, $headers);

			 echo 'Please check your email to activate your account!';
    }

    else

        {

            echo 'Could Not Prepare Field';  

        }

   

 }

        $sql->close();

 

    }

    else

        {

            echo 'Could Not Prepare Field';  

        }

       

        $con->close();

 

   

 

?>