<?php

//session_start();
require 'dbcon.php';


/*//db connection constants

$DATABASE_HOST = 'localhost';
$DATABASE_USER = 'W01232820';
$DATABASE_PASS = 'Ashtoncs!';
$DATABASE_NAME = 'W01232820';

// Try and connect using the info above.
$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);

if ( mysqli_connect_errno() ) {

  // If there is an error with the connection, stop the script and display the error.
die ('Failed to connect to MySQL: ' . mysqli_connect_error());
}*/

 

// Now we check if the data from the login form was submitted, isset() will check if the data exists.
if ( !isset($_POST['username'], $_POST['password']) ) {

// Could not get the data that should have been sent.
die ('Please fill both the username and password field!');

}

// Prepare our SQL, preparing the SQL statement will prevent SQL injection.
if ($sql = $con->prepare('SELECT id, password, activation_code FROM accounts WHERE username = ?')) {

// Bind parameters (s = string, i = int, b = blob, etc), in our case the username is a string so we use "s"
$sql->bind_param('s', $_POST['username']);
$sql->execute();

// Store the result so we can check if the account exists in the database.
$sql->store_result();

if ($sql->num_rows > 0) {

$sql->bind_result($id, $password, $activation_code);

$sql->fetch();

// Account exists, now we verify the password.

// Note: remember to use password_hash in your registration file to store the hashed passwords.

if (password_verify($_POST['password'], $password)) {

// Verification success! User has loggedin!

// Create sessions so we know the user is logged in, they basically act like cookies but remember the data on the server.

session_regenerate_id();

$_SESSION['loggedin'] = TRUE;

if($activation_code == "activated")
{	
	$_SESSION['activation_code'] = TRUE;
}

$_SESSION['name'] = $_POST['username'];

$_SESSION['id'] = $id;

//echo 'Welcome ' . $_SESSION['name'] . '!';

    header('Location: home.php');

} else {

echo 'Incorrect password!';
      
	  header('Location: index.php?message=Incorrect Password');
	/*<?php <p class="displayerr">Incorrect Password, please enter again</p>?>;*/
}

} else {

echo 'Incorrect username!';
  //header('Location: index.html?message=Incorrect Username');
  header('Location: index.php?message=Incorrect Username');
  //<?php <p class="displayerr">Incorrect Username, please enter again</p>;

}

  //here is where the error was. our code needed to go before the close...

$sql->close();

}

?>