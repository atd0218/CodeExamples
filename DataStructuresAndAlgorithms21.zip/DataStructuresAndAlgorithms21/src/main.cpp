#include<iostream>
#include<iomanip>
#include "range.h"
using namespace std;

int main()
{
   
    cout << "hello world" << endl;
	Range<int> r(3, 11);
	cout << r << endl;

    Range<int> a(12,-24,-2);
    Range<double>b(23.5, 76.9, 8.3);

    cout << a << endl << b << endl;

    /*ostream& operator<<(ostream& cout, const Range<int>& me)
    {
       cout << me.a << endl << me.b;
       
       return me; 
    }*/

    

   /* for(int v : a.values()){
        cout << v << endl;
    }

    for(int v : b.values()){
        cout << v << endl;
    }*/

    return 0;


}